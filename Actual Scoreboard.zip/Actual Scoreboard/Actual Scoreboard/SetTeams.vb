﻿Public Class SetTeams
    Private Sub SetTeams_Load(sender As Object, e As EventArgs) Handles Me.Load
        tbHomeTM.Text = Form1.lblHomeTM.Text
        tbAwayTM.Text = Form1.lblAwayTM.Text
    End Sub

    Private Sub btnOK_Click(sender As Object, e As EventArgs) Handles btnOK.Click
        If tbHomeTM.Text <> "" Then
            Form1.lblHomeTM.Text = UCase(tbHomeTM.Text)
        Else
            Form1.lblHomeTM.Text = "Team 1"
        End If

        If tbAwayTM.Text <> "" Then
            Form1.lblAwayTM.Text = UCase(tbAwayTM.Text)
        Else
            Form1.lblAwayTM.Text = "Team 2"
        End If
        Me.Close()
        Me.Dispose()

    End Sub


End Class