﻿Public Class Form1
    Public currenttime As Integer

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        currenttime = 600
        RenderClock()
    End Sub
    Private Sub tmrMainClock_Tick(sender As Object, e As EventArgs) Handles tmrMainClock.Tick
        currenttime -= 1
        RenderClock()

        If currenttime = 0 Then
            tmrMainClock.Stop()
            MsgBox("End of Quarter")
            lblQTR.Text = Val(lblQTR.Text) + 1
        End If
    End Sub

    Public Sub RenderClock()
        Dim timeOut As String
        Dim intMins, intsec As Integer
        intMins = currenttime \ 60
        intsec = currenttime Mod 60

        If intsec > 9 Then
            timeOut = $"{intMins}:{intsec}"
        Else
            timeOut = $"{intMins}:0{intsec}"
        End If
        lblMainClock.Text = timeOut
    End Sub

    Private Sub btnShowController_Click(sender As Object, e As EventArgs) Handles btnShowController.Click 'Shows the controller
        Controller.ShowDialog(Me)
    End Sub

End Class