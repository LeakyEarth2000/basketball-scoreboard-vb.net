﻿Public Class Form1
    Dim CNTR As Integer
    Dim MNTE As Integer
    Dim SCND As Integer
    Dim MS As Integer
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        tmrClock.Stop()
        'Started = False
        CNTR = 0
        MNTE = 10
        SCND = 0
        MS = 0

        lblClockSS.Text = Format(MNTE, "00") & ":" & Format(SCND, "00")
        lblClockMS.Text = MS
    End Sub

    Private Sub btnShowController_Click(sender As Object, e As EventArgs) Handles btnShowController.Click 'Shows the controller
        Controller.ShowDialog(Me)
    End Sub

    Private Sub btnStart_Click(sender As Object, e As EventArgs) Handles btnStart.Click

    End Sub

    Private Sub btnStop_Click(sender As Object, e As EventArgs) Handles btnStop.Click

    End Sub

    Private Sub btnReset_Click(sender As Object, e As EventArgs) Handles btnReset.Click

    End Sub
End Class