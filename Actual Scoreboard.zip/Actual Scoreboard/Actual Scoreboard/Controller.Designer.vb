﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Controller
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.btnT1Sp1 = New System.Windows.Forms.Button()
        Me.lblT1 = New System.Windows.Forms.Label()
        Me.btnT1Sn1 = New System.Windows.Forms.Button()
        Me.btnT1Sn2 = New System.Windows.Forms.Button()
        Me.btnT1Sp2 = New System.Windows.Forms.Button()
        Me.btnT1Sp3 = New System.Windows.Forms.Button()
        Me.btnT1Sn3 = New System.Windows.Forms.Button()
        Me.lblBlocks = New System.Windows.Forms.Label()
        Me.lblFoul = New System.Windows.Forms.Label()
        Me.lblT2 = New System.Windows.Forms.Label()
        Me.lblSteals = New System.Windows.Forms.Label()
        Me.btnT1Stealsp = New System.Windows.Forms.Button()
        Me.btnT1Blocksp = New System.Windows.Forms.Button()
        Me.btnT1Foulsp = New System.Windows.Forms.Button()
        Me.btnT1Stealsn = New System.Windows.Forms.Button()
        Me.btnT1Blocksn = New System.Windows.Forms.Button()
        Me.btnT1Foulsn = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.btnT2Foulsn = New System.Windows.Forms.Button()
        Me.btnT2Blockssn = New System.Windows.Forms.Button()
        Me.btnT2Stealssn = New System.Windows.Forms.Button()
        Me.btnT2Foulsp = New System.Windows.Forms.Button()
        Me.btnT2Blockssp = New System.Windows.Forms.Button()
        Me.btnT2Stealssp = New System.Windows.Forms.Button()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.btnT2Sn3 = New System.Windows.Forms.Button()
        Me.btnT2Sp3 = New System.Windows.Forms.Button()
        Me.btnT2Sp2 = New System.Windows.Forms.Button()
        Me.btnT2Sn2 = New System.Windows.Forms.Button()
        Me.btnT2Sn1 = New System.Windows.Forms.Button()
        Me.btnT2Sp1 = New System.Windows.Forms.Button()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.btnReset = New System.Windows.Forms.Button()
        Me.btnStop = New System.Windows.Forms.Button()
        Me.btnStart = New System.Windows.Forms.Button()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Button17 = New System.Windows.Forms.Button()
        Me.btnStadium = New System.Windows.Forms.Button()
        Me.btnEditTime = New System.Windows.Forms.Button()
        Me.btnChangeTMs = New System.Windows.Forms.Button()
        Me.btnCloseController = New System.Windows.Forms.Button()
        Me.btnT1FreeThrowssn = New System.Windows.Forms.Button()
        Me.btnT1FreeThrowssp = New System.Windows.Forms.Button()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.btnT13Pointerssn = New System.Windows.Forms.Button()
        Me.btnT13Pointerssp = New System.Windows.Forms.Button()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.btnT12Pointerssn = New System.Windows.Forms.Button()
        Me.btnT12Pointerssp = New System.Windows.Forms.Button()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.btnT22Pointerssn = New System.Windows.Forms.Button()
        Me.btnT22Pointerssp = New System.Windows.Forms.Button()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.btnT23Pointerssn = New System.Windows.Forms.Button()
        Me.btnT23Pointerssp = New System.Windows.Forms.Button()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.btnT2FreeThrowssn = New System.Windows.Forms.Button()
        Me.btnT2FreeThrowssp = New System.Windows.Forms.Button()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.btnQTR = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'btnT1Sp1
        '
        Me.btnT1Sp1.Location = New System.Drawing.Point(186, 96)
        Me.btnT1Sp1.Name = "btnT1Sp1"
        Me.btnT1Sp1.Size = New System.Drawing.Size(45, 23)
        Me.btnT1Sp1.TabIndex = 0
        Me.btnT1Sp1.Text = "+1"
        Me.btnT1Sp1.UseVisualStyleBackColor = True
        '
        'lblT1
        '
        Me.lblT1.AutoSize = True
        Me.lblT1.Font = New System.Drawing.Font("Segoe UI Black", 36.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.lblT1.Location = New System.Drawing.Point(108, 13)
        Me.lblT1.Name = "lblT1"
        Me.lblT1.Size = New System.Drawing.Size(195, 65)
        Me.lblT1.TabIndex = 1
        Me.lblT1.Text = "Team 1"
        '
        'btnT1Sn1
        '
        Me.btnT1Sn1.Location = New System.Drawing.Point(186, 125)
        Me.btnT1Sn1.Name = "btnT1Sn1"
        Me.btnT1Sn1.Size = New System.Drawing.Size(45, 23)
        Me.btnT1Sn1.TabIndex = 5
        Me.btnT1Sn1.Text = "-1"
        Me.btnT1Sn1.UseVisualStyleBackColor = True
        '
        'btnT1Sn2
        '
        Me.btnT1Sn2.Location = New System.Drawing.Point(246, 125)
        Me.btnT1Sn2.Name = "btnT1Sn2"
        Me.btnT1Sn2.Size = New System.Drawing.Size(45, 23)
        Me.btnT1Sn2.TabIndex = 6
        Me.btnT1Sn2.Text = "-2"
        Me.btnT1Sn2.UseVisualStyleBackColor = True
        '
        'btnT1Sp2
        '
        Me.btnT1Sp2.Location = New System.Drawing.Point(246, 96)
        Me.btnT1Sp2.Name = "btnT1Sp2"
        Me.btnT1Sp2.Size = New System.Drawing.Size(45, 23)
        Me.btnT1Sp2.TabIndex = 7
        Me.btnT1Sp2.Text = "+2"
        Me.btnT1Sp2.UseVisualStyleBackColor = True
        '
        'btnT1Sp3
        '
        Me.btnT1Sp3.Location = New System.Drawing.Point(307, 96)
        Me.btnT1Sp3.Name = "btnT1Sp3"
        Me.btnT1Sp3.Size = New System.Drawing.Size(45, 23)
        Me.btnT1Sp3.TabIndex = 10
        Me.btnT1Sp3.Text = "+3"
        Me.btnT1Sp3.UseVisualStyleBackColor = True
        '
        'btnT1Sn3
        '
        Me.btnT1Sn3.Location = New System.Drawing.Point(307, 125)
        Me.btnT1Sn3.Name = "btnT1Sn3"
        Me.btnT1Sn3.Size = New System.Drawing.Size(45, 23)
        Me.btnT1Sn3.TabIndex = 11
        Me.btnT1Sn3.Text = "-3"
        Me.btnT1Sn3.UseVisualStyleBackColor = True
        '
        'lblBlocks
        '
        Me.lblBlocks.AutoSize = True
        Me.lblBlocks.Font = New System.Drawing.Font("Stencil", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.lblBlocks.Location = New System.Drawing.Point(67, 232)
        Me.lblBlocks.Name = "lblBlocks"
        Me.lblBlocks.Size = New System.Drawing.Size(69, 19)
        Me.lblBlocks.TabIndex = 14
        Me.lblBlocks.Text = "Blocks"
        '
        'lblFoul
        '
        Me.lblFoul.AutoSize = True
        Me.lblFoul.Font = New System.Drawing.Font("Stencil", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.lblFoul.Location = New System.Drawing.Point(76, 199)
        Me.lblFoul.Name = "lblFoul"
        Me.lblFoul.Size = New System.Drawing.Size(57, 19)
        Me.lblFoul.TabIndex = 15
        Me.lblFoul.Text = "Fouls"
        '
        'lblT2
        '
        Me.lblT2.Font = New System.Drawing.Font("Segoe UI Black", 36.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.lblT2.Location = New System.Drawing.Point(545, 13)
        Me.lblT2.Name = "lblT2"
        Me.lblT2.Size = New System.Drawing.Size(227, 64)
        Me.lblT2.TabIndex = 25
        Me.lblT2.Text = "Team 2"
        '
        'lblSteals
        '
        Me.lblSteals.AutoSize = True
        Me.lblSteals.Font = New System.Drawing.Font("Stencil", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.lblSteals.Location = New System.Drawing.Point(67, 261)
        Me.lblSteals.Name = "lblSteals"
        Me.lblSteals.Size = New System.Drawing.Size(65, 19)
        Me.lblSteals.TabIndex = 35
        Me.lblSteals.Text = "Steals"
        '
        'btnT1Stealsp
        '
        Me.btnT1Stealsp.Location = New System.Drawing.Point(195, 261)
        Me.btnT1Stealsp.Name = "btnT1Stealsp"
        Me.btnT1Stealsp.Size = New System.Drawing.Size(75, 23)
        Me.btnT1Stealsp.TabIndex = 54
        Me.btnT1Stealsp.Text = "+1"
        Me.btnT1Stealsp.UseVisualStyleBackColor = True
        '
        'btnT1Blocksp
        '
        Me.btnT1Blocksp.Location = New System.Drawing.Point(195, 231)
        Me.btnT1Blocksp.Name = "btnT1Blocksp"
        Me.btnT1Blocksp.Size = New System.Drawing.Size(75, 23)
        Me.btnT1Blocksp.TabIndex = 56
        Me.btnT1Blocksp.Text = "+1"
        Me.btnT1Blocksp.UseVisualStyleBackColor = True
        '
        'btnT1Foulsp
        '
        Me.btnT1Foulsp.Location = New System.Drawing.Point(195, 199)
        Me.btnT1Foulsp.Name = "btnT1Foulsp"
        Me.btnT1Foulsp.Size = New System.Drawing.Size(75, 23)
        Me.btnT1Foulsp.TabIndex = 57
        Me.btnT1Foulsp.Text = "+1"
        Me.btnT1Foulsp.UseVisualStyleBackColor = True
        '
        'btnT1Stealsn
        '
        Me.btnT1Stealsn.Location = New System.Drawing.Point(276, 261)
        Me.btnT1Stealsn.Name = "btnT1Stealsn"
        Me.btnT1Stealsn.Size = New System.Drawing.Size(75, 23)
        Me.btnT1Stealsn.TabIndex = 65
        Me.btnT1Stealsn.Text = "-1"
        Me.btnT1Stealsn.UseVisualStyleBackColor = True
        '
        'btnT1Blocksn
        '
        Me.btnT1Blocksn.Location = New System.Drawing.Point(276, 231)
        Me.btnT1Blocksn.Name = "btnT1Blocksn"
        Me.btnT1Blocksn.Size = New System.Drawing.Size(75, 23)
        Me.btnT1Blocksn.TabIndex = 67
        Me.btnT1Blocksn.Text = "-1"
        Me.btnT1Blocksn.UseVisualStyleBackColor = True
        '
        'btnT1Foulsn
        '
        Me.btnT1Foulsn.Location = New System.Drawing.Point(276, 199)
        Me.btnT1Foulsn.Name = "btnT1Foulsn"
        Me.btnT1Foulsn.Size = New System.Drawing.Size(75, 23)
        Me.btnT1Foulsn.TabIndex = 68
        Me.btnT1Foulsn.Text = "-1"
        Me.btnT1Foulsn.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("Segoe UI", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label1.Location = New System.Drawing.Point(417, 4)
        Me.Label1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(28, 358)
        Me.Label1.TabIndex = 75
        Me.Label1.Text = "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) &
    "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Stencil", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label2.Location = New System.Drawing.Point(88, 113)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(68, 22)
        Me.Label2.TabIndex = 76
        Me.Label2.Text = "Score"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Stencil", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label3.Location = New System.Drawing.Point(521, 113)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(68, 22)
        Me.Label3.TabIndex = 98
        Me.Label3.Text = "Score"
        '
        'btnT2Foulsn
        '
        Me.btnT2Foulsn.Location = New System.Drawing.Point(709, 199)
        Me.btnT2Foulsn.Name = "btnT2Foulsn"
        Me.btnT2Foulsn.Size = New System.Drawing.Size(75, 23)
        Me.btnT2Foulsn.TabIndex = 97
        Me.btnT2Foulsn.Text = "-1"
        Me.btnT2Foulsn.UseVisualStyleBackColor = True
        '
        'btnT2Blockssn
        '
        Me.btnT2Blockssn.Location = New System.Drawing.Point(710, 231)
        Me.btnT2Blockssn.Name = "btnT2Blockssn"
        Me.btnT2Blockssn.Size = New System.Drawing.Size(75, 23)
        Me.btnT2Blockssn.TabIndex = 96
        Me.btnT2Blockssn.Text = "-1"
        Me.btnT2Blockssn.UseVisualStyleBackColor = True
        '
        'btnT2Stealssn
        '
        Me.btnT2Stealssn.Location = New System.Drawing.Point(710, 260)
        Me.btnT2Stealssn.Name = "btnT2Stealssn"
        Me.btnT2Stealssn.Size = New System.Drawing.Size(75, 23)
        Me.btnT2Stealssn.TabIndex = 94
        Me.btnT2Stealssn.Text = "-1"
        Me.btnT2Stealssn.UseVisualStyleBackColor = True
        '
        'btnT2Foulsp
        '
        Me.btnT2Foulsp.Location = New System.Drawing.Point(628, 199)
        Me.btnT2Foulsp.Name = "btnT2Foulsp"
        Me.btnT2Foulsp.Size = New System.Drawing.Size(75, 23)
        Me.btnT2Foulsp.TabIndex = 92
        Me.btnT2Foulsp.Text = "+1"
        Me.btnT2Foulsp.UseVisualStyleBackColor = True
        '
        'btnT2Blockssp
        '
        Me.btnT2Blockssp.Location = New System.Drawing.Point(629, 231)
        Me.btnT2Blockssp.Name = "btnT2Blockssp"
        Me.btnT2Blockssp.Size = New System.Drawing.Size(75, 23)
        Me.btnT2Blockssp.TabIndex = 91
        Me.btnT2Blockssp.Text = "+1"
        Me.btnT2Blockssp.UseVisualStyleBackColor = True
        '
        'btnT2Stealssp
        '
        Me.btnT2Stealssp.Location = New System.Drawing.Point(629, 260)
        Me.btnT2Stealssp.Name = "btnT2Stealssp"
        Me.btnT2Stealssp.Size = New System.Drawing.Size(75, 23)
        Me.btnT2Stealssp.TabIndex = 89
        Me.btnT2Stealssp.Text = "+1"
        Me.btnT2Stealssp.UseVisualStyleBackColor = True
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Stencil", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label6.Location = New System.Drawing.Point(500, 260)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(65, 19)
        Me.Label6.TabIndex = 85
        Me.Label6.Text = "Steals"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Stencil", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label7.Location = New System.Drawing.Point(508, 199)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(57, 19)
        Me.Label7.TabIndex = 84
        Me.Label7.Text = "Fouls"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Stencil", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label8.Location = New System.Drawing.Point(500, 232)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(69, 19)
        Me.Label8.TabIndex = 83
        Me.Label8.Text = "Blocks"
        '
        'btnT2Sn3
        '
        Me.btnT2Sn3.Location = New System.Drawing.Point(740, 125)
        Me.btnT2Sn3.Name = "btnT2Sn3"
        Me.btnT2Sn3.Size = New System.Drawing.Size(45, 23)
        Me.btnT2Sn3.TabIndex = 82
        Me.btnT2Sn3.Text = "-3"
        Me.btnT2Sn3.UseVisualStyleBackColor = True
        '
        'btnT2Sp3
        '
        Me.btnT2Sp3.Location = New System.Drawing.Point(740, 96)
        Me.btnT2Sp3.Name = "btnT2Sp3"
        Me.btnT2Sp3.Size = New System.Drawing.Size(45, 23)
        Me.btnT2Sp3.TabIndex = 81
        Me.btnT2Sp3.Text = "+3"
        Me.btnT2Sp3.UseVisualStyleBackColor = True
        '
        'btnT2Sp2
        '
        Me.btnT2Sp2.Location = New System.Drawing.Point(679, 96)
        Me.btnT2Sp2.Name = "btnT2Sp2"
        Me.btnT2Sp2.Size = New System.Drawing.Size(45, 23)
        Me.btnT2Sp2.TabIndex = 80
        Me.btnT2Sp2.Text = "+2"
        Me.btnT2Sp2.UseVisualStyleBackColor = True
        '
        'btnT2Sn2
        '
        Me.btnT2Sn2.Location = New System.Drawing.Point(679, 125)
        Me.btnT2Sn2.Name = "btnT2Sn2"
        Me.btnT2Sn2.Size = New System.Drawing.Size(45, 23)
        Me.btnT2Sn2.TabIndex = 79
        Me.btnT2Sn2.Text = "-2"
        Me.btnT2Sn2.UseVisualStyleBackColor = True
        '
        'btnT2Sn1
        '
        Me.btnT2Sn1.Location = New System.Drawing.Point(619, 125)
        Me.btnT2Sn1.Name = "btnT2Sn1"
        Me.btnT2Sn1.Size = New System.Drawing.Size(45, 23)
        Me.btnT2Sn1.TabIndex = 78
        Me.btnT2Sn1.Text = "-1"
        Me.btnT2Sn1.UseVisualStyleBackColor = True
        '
        'btnT2Sp1
        '
        Me.btnT2Sp1.Location = New System.Drawing.Point(619, 96)
        Me.btnT2Sp1.Name = "btnT2Sp1"
        Me.btnT2Sp1.Size = New System.Drawing.Size(45, 23)
        Me.btnT2Sp1.TabIndex = 77
        Me.btnT2Sp1.Text = "+1"
        Me.btnT2Sp1.UseVisualStyleBackColor = True
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Segoe UI Black", 36.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label10.Location = New System.Drawing.Point(329, 464)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(155, 65)
        Me.Label10.TabIndex = 100
        Me.Label10.Text = "Clock"
        '
        'btnReset
        '
        Me.btnReset.Location = New System.Drawing.Point(376, 530)
        Me.btnReset.Name = "btnReset"
        Me.btnReset.Size = New System.Drawing.Size(75, 23)
        Me.btnReset.TabIndex = 103
        Me.btnReset.Text = "Reset"
        Me.btnReset.UseVisualStyleBackColor = True
        '
        'btnStop
        '
        Me.btnStop.Font = New System.Drawing.Font("Segoe UI", 16.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.btnStop.Location = New System.Drawing.Point(417, 424)
        Me.btnStop.Name = "btnStop"
        Me.btnStop.Size = New System.Drawing.Size(102, 38)
        Me.btnStop.TabIndex = 102
        Me.btnStop.Text = "Stop"
        Me.btnStop.UseVisualStyleBackColor = True
        '
        'btnStart
        '
        Me.btnStart.Font = New System.Drawing.Font("Segoe UI", 16.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.btnStart.Location = New System.Drawing.Point(303, 424)
        Me.btnStart.Name = "btnStart"
        Me.btnStart.Size = New System.Drawing.Size(102, 38)
        Me.btnStart.TabIndex = 101
        Me.btnStart.Text = "Start"
        Me.btnStart.UseVisualStyleBackColor = True
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Segoe UI Black", 36.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label11.Location = New System.Drawing.Point(277, 556)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(275, 65)
        Me.Label11.TabIndex = 104
        Me.Label11.Text = "Shot Clock"
        '
        'Button17
        '
        Me.Button17.Location = New System.Drawing.Point(376, 617)
        Me.Button17.Name = "Button17"
        Me.Button17.Size = New System.Drawing.Size(75, 23)
        Me.Button17.TabIndex = 105
        Me.Button17.Text = "Reset"
        Me.Button17.UseVisualStyleBackColor = True
        '
        'btnStadium
        '
        Me.btnStadium.Font = New System.Drawing.Font("Segoe UI", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.btnStadium.Location = New System.Drawing.Point(521, 690)
        Me.btnStadium.Name = "btnStadium"
        Me.btnStadium.Size = New System.Drawing.Size(153, 62)
        Me.btnStadium.TabIndex = 108
        Me.btnStadium.Text = "Edit Stadium"
        Me.btnStadium.UseVisualStyleBackColor = True
        '
        'btnEditTime
        '
        Me.btnEditTime.Font = New System.Drawing.Font("Segoe UI", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.btnEditTime.Location = New System.Drawing.Point(134, 690)
        Me.btnEditTime.Name = "btnEditTime"
        Me.btnEditTime.Size = New System.Drawing.Size(153, 62)
        Me.btnEditTime.TabIndex = 107
        Me.btnEditTime.Text = "Edit Time"
        Me.btnEditTime.UseVisualStyleBackColor = True
        '
        'btnChangeTMs
        '
        Me.btnChangeTMs.Font = New System.Drawing.Font("Segoe UI", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.btnChangeTMs.Location = New System.Drawing.Point(322, 690)
        Me.btnChangeTMs.Margin = New System.Windows.Forms.Padding(2)
        Me.btnChangeTMs.Name = "btnChangeTMs"
        Me.btnChangeTMs.Size = New System.Drawing.Size(163, 62)
        Me.btnChangeTMs.TabIndex = 106
        Me.btnChangeTMs.Text = "Change Teams"
        Me.btnChangeTMs.UseVisualStyleBackColor = True
        '
        'btnCloseController
        '
        Me.btnCloseController.Font = New System.Drawing.Font("Segoe UI", 16.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.btnCloseController.Location = New System.Drawing.Point(307, 774)
        Me.btnCloseController.Margin = New System.Windows.Forms.Padding(2)
        Me.btnCloseController.Name = "btnCloseController"
        Me.btnCloseController.Size = New System.Drawing.Size(196, 62)
        Me.btnCloseController.TabIndex = 109
        Me.btnCloseController.Text = "Close Controller"
        Me.btnCloseController.UseVisualStyleBackColor = True
        '
        'btnT1FreeThrowssn
        '
        Me.btnT1FreeThrowssn.Location = New System.Drawing.Point(279, 313)
        Me.btnT1FreeThrowssn.Name = "btnT1FreeThrowssn"
        Me.btnT1FreeThrowssn.Size = New System.Drawing.Size(75, 23)
        Me.btnT1FreeThrowssn.TabIndex = 112
        Me.btnT1FreeThrowssn.Text = "-1"
        Me.btnT1FreeThrowssn.UseVisualStyleBackColor = True
        '
        'btnT1FreeThrowssp
        '
        Me.btnT1FreeThrowssp.Location = New System.Drawing.Point(198, 313)
        Me.btnT1FreeThrowssp.Name = "btnT1FreeThrowssp"
        Me.btnT1FreeThrowssp.Size = New System.Drawing.Size(75, 23)
        Me.btnT1FreeThrowssp.TabIndex = 111
        Me.btnT1FreeThrowssp.Text = "+1"
        Me.btnT1FreeThrowssp.UseVisualStyleBackColor = True
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Stencil", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label4.Location = New System.Drawing.Point(58, 313)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(116, 19)
        Me.Label4.TabIndex = 110
        Me.Label4.Text = "Free throws"
        '
        'btnT13Pointerssn
        '
        Me.btnT13Pointerssn.Location = New System.Drawing.Point(279, 375)
        Me.btnT13Pointerssn.Name = "btnT13Pointerssn"
        Me.btnT13Pointerssn.Size = New System.Drawing.Size(75, 23)
        Me.btnT13Pointerssn.TabIndex = 118
        Me.btnT13Pointerssn.Text = "-1"
        Me.btnT13Pointerssn.UseVisualStyleBackColor = True
        '
        'btnT13Pointerssp
        '
        Me.btnT13Pointerssp.Location = New System.Drawing.Point(198, 375)
        Me.btnT13Pointerssp.Name = "btnT13Pointerssp"
        Me.btnT13Pointerssp.Size = New System.Drawing.Size(75, 23)
        Me.btnT13Pointerssp.TabIndex = 117
        Me.btnT13Pointerssp.Text = "+1"
        Me.btnT13Pointerssp.UseVisualStyleBackColor = True
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Stencil", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label9.Location = New System.Drawing.Point(58, 375)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(98, 19)
        Me.Label9.TabIndex = 116
        Me.Label9.Text = "3-Pointers"
        '
        'btnT12Pointerssn
        '
        Me.btnT12Pointerssn.Location = New System.Drawing.Point(279, 344)
        Me.btnT12Pointerssn.Name = "btnT12Pointerssn"
        Me.btnT12Pointerssn.Size = New System.Drawing.Size(75, 23)
        Me.btnT12Pointerssn.TabIndex = 121
        Me.btnT12Pointerssn.Text = "-1"
        Me.btnT12Pointerssn.UseVisualStyleBackColor = True
        '
        'btnT12Pointerssp
        '
        Me.btnT12Pointerssp.Location = New System.Drawing.Point(198, 344)
        Me.btnT12Pointerssp.Name = "btnT12Pointerssp"
        Me.btnT12Pointerssp.Size = New System.Drawing.Size(75, 23)
        Me.btnT12Pointerssp.TabIndex = 120
        Me.btnT12Pointerssp.Text = "+1"
        Me.btnT12Pointerssp.UseVisualStyleBackColor = True
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Stencil", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label12.Location = New System.Drawing.Point(58, 344)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(98, 19)
        Me.Label12.TabIndex = 119
        Me.Label12.Text = "2-Pointers"
        '
        'btnT22Pointerssn
        '
        Me.btnT22Pointerssn.Location = New System.Drawing.Point(710, 344)
        Me.btnT22Pointerssn.Name = "btnT22Pointerssn"
        Me.btnT22Pointerssn.Size = New System.Drawing.Size(75, 23)
        Me.btnT22Pointerssn.TabIndex = 130
        Me.btnT22Pointerssn.Text = "-1"
        Me.btnT22Pointerssn.UseVisualStyleBackColor = True
        '
        'btnT22Pointerssp
        '
        Me.btnT22Pointerssp.Location = New System.Drawing.Point(629, 344)
        Me.btnT22Pointerssp.Name = "btnT22Pointerssp"
        Me.btnT22Pointerssp.Size = New System.Drawing.Size(75, 23)
        Me.btnT22Pointerssp.TabIndex = 129
        Me.btnT22Pointerssp.Text = "+1"
        Me.btnT22Pointerssp.UseVisualStyleBackColor = True
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Stencil", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label13.Location = New System.Drawing.Point(489, 344)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(98, 19)
        Me.Label13.TabIndex = 128
        Me.Label13.Text = "2-Pointers"
        '
        'btnT23Pointerssn
        '
        Me.btnT23Pointerssn.Location = New System.Drawing.Point(710, 375)
        Me.btnT23Pointerssn.Name = "btnT23Pointerssn"
        Me.btnT23Pointerssn.Size = New System.Drawing.Size(75, 23)
        Me.btnT23Pointerssn.TabIndex = 127
        Me.btnT23Pointerssn.Text = "-1"
        Me.btnT23Pointerssn.UseVisualStyleBackColor = True
        '
        'btnT23Pointerssp
        '
        Me.btnT23Pointerssp.Location = New System.Drawing.Point(629, 375)
        Me.btnT23Pointerssp.Name = "btnT23Pointerssp"
        Me.btnT23Pointerssp.Size = New System.Drawing.Size(75, 23)
        Me.btnT23Pointerssp.TabIndex = 126
        Me.btnT23Pointerssp.Text = "+1"
        Me.btnT23Pointerssp.UseVisualStyleBackColor = True
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Stencil", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label14.Location = New System.Drawing.Point(489, 375)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(98, 19)
        Me.Label14.TabIndex = 125
        Me.Label14.Text = "3-Pointers"
        '
        'btnT2FreeThrowssn
        '
        Me.btnT2FreeThrowssn.Location = New System.Drawing.Point(710, 313)
        Me.btnT2FreeThrowssn.Name = "btnT2FreeThrowssn"
        Me.btnT2FreeThrowssn.Size = New System.Drawing.Size(75, 23)
        Me.btnT2FreeThrowssn.TabIndex = 124
        Me.btnT2FreeThrowssn.Text = "-1"
        Me.btnT2FreeThrowssn.UseVisualStyleBackColor = True
        '
        'btnT2FreeThrowssp
        '
        Me.btnT2FreeThrowssp.Location = New System.Drawing.Point(629, 313)
        Me.btnT2FreeThrowssp.Name = "btnT2FreeThrowssp"
        Me.btnT2FreeThrowssp.Size = New System.Drawing.Size(75, 23)
        Me.btnT2FreeThrowssp.TabIndex = 123
        Me.btnT2FreeThrowssp.Text = "+1"
        Me.btnT2FreeThrowssp.UseVisualStyleBackColor = True
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Stencil", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label15.Location = New System.Drawing.Point(489, 313)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(116, 19)
        Me.Label15.TabIndex = 122
        Me.Label15.Text = "Free throws"
        '
        'btnQTR
        '
        Me.btnQTR.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.btnQTR.Location = New System.Drawing.Point(376, 365)
        Me.btnQTR.Name = "btnQTR"
        Me.btnQTR.Size = New System.Drawing.Size(92, 43)
        Me.btnQTR.TabIndex = 131
        Me.btnQTR.Text = "Quarter Up"
        Me.btnQTR.UseVisualStyleBackColor = True
        '
        'Controller
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(848, 769)
        Me.Controls.Add(Me.btnQTR)
        Me.Controls.Add(Me.btnT22Pointerssn)
        Me.Controls.Add(Me.btnT22Pointerssp)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.btnT23Pointerssn)
        Me.Controls.Add(Me.btnT23Pointerssp)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.btnT2FreeThrowssn)
        Me.Controls.Add(Me.btnT2FreeThrowssp)
        Me.Controls.Add(Me.Label15)
        Me.Controls.Add(Me.btnT12Pointerssn)
        Me.Controls.Add(Me.btnT12Pointerssp)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.btnT13Pointerssn)
        Me.Controls.Add(Me.btnT13Pointerssp)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.btnT1FreeThrowssn)
        Me.Controls.Add(Me.btnT1FreeThrowssp)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.btnCloseController)
        Me.Controls.Add(Me.btnStadium)
        Me.Controls.Add(Me.btnEditTime)
        Me.Controls.Add(Me.btnChangeTMs)
        Me.Controls.Add(Me.Button17)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.btnReset)
        Me.Controls.Add(Me.btnStop)
        Me.Controls.Add(Me.btnStart)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.btnT2Foulsn)
        Me.Controls.Add(Me.btnT2Blockssn)
        Me.Controls.Add(Me.btnT2Stealssn)
        Me.Controls.Add(Me.btnT2Foulsp)
        Me.Controls.Add(Me.btnT2Blockssp)
        Me.Controls.Add(Me.btnT2Stealssp)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.btnT2Sn3)
        Me.Controls.Add(Me.btnT2Sp3)
        Me.Controls.Add(Me.btnT2Sp2)
        Me.Controls.Add(Me.btnT2Sn2)
        Me.Controls.Add(Me.btnT2Sn1)
        Me.Controls.Add(Me.btnT2Sp1)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.btnT1Foulsn)
        Me.Controls.Add(Me.btnT1Blocksn)
        Me.Controls.Add(Me.btnT1Stealsn)
        Me.Controls.Add(Me.btnT1Foulsp)
        Me.Controls.Add(Me.btnT1Blocksp)
        Me.Controls.Add(Me.btnT1Stealsp)
        Me.Controls.Add(Me.lblSteals)
        Me.Controls.Add(Me.lblT2)
        Me.Controls.Add(Me.lblFoul)
        Me.Controls.Add(Me.lblBlocks)
        Me.Controls.Add(Me.btnT1Sn3)
        Me.Controls.Add(Me.btnT1Sp3)
        Me.Controls.Add(Me.btnT1Sp2)
        Me.Controls.Add(Me.btnT1Sn2)
        Me.Controls.Add(Me.btnT1Sn1)
        Me.Controls.Add(Me.lblT1)
        Me.Controls.Add(Me.btnT1Sp1)
        Me.Name = "Controller"
        Me.Text = "SS"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnT1Sp1 As Button
    Friend WithEvents lblT1 As Label
    Friend WithEvents btnT1Sn1 As Button
    Friend WithEvents btnT1Sn2 As Button
    Friend WithEvents btnT1Sp2 As Button
    Friend WithEvents btnT1Sp3 As Button
    Friend WithEvents btnT1Sn3 As Button
    Friend WithEvents lblBlocks As Label
    Friend WithEvents lblFoul As Label
    Friend WithEvents lblT2 As Label
    Friend WithEvents lblSteals As Label
    Friend WithEvents btnT1Stealsp As Button
    Friend WithEvents btnT1Blocksp As Button
    Friend WithEvents btnT1Foulsp As Button
    Friend WithEvents btnT1Stealsn As Button
    Friend WithEvents btnT1Blocksn As Button
    Friend WithEvents btnT1Foulsn As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents btnT2Foulsn As Button
    Friend WithEvents btnT2Blockssn As Button
    Friend WithEvents btnT2Stealssn As Button
    Friend WithEvents btnT2Foulsp As Button
    Friend WithEvents btnT2Blockssp As Button
    Friend WithEvents btnT2Stealssp As Button
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents btnT2Sn3 As Button
    Friend WithEvents btnT2Sp3 As Button
    Friend WithEvents btnT2Sp2 As Button
    Friend WithEvents btnT2Sn2 As Button
    Friend WithEvents btnT2Sn1 As Button
    Friend WithEvents btnT2Sp1 As Button
    Friend WithEvents Label10 As Label
    Friend WithEvents btnReset As Button
    Friend WithEvents btnStop As Button
    Friend WithEvents btnStart As Button
    Friend WithEvents Label11 As Label
    Friend WithEvents Button17 As Button
    Friend WithEvents btnStadium As Button
    Friend WithEvents btnEditTime As Button
    Friend WithEvents btnChangeTMs As Button
    Friend WithEvents btnCloseController As Button
    Friend WithEvents btnT1FreeThrowssn As Button
    Friend WithEvents btnT1FreeThrowssp As Button
    Friend WithEvents Label4 As Label
    Friend WithEvents btnT13Pointerssn As Button
    Friend WithEvents btnT13Pointerssp As Button
    Friend WithEvents Label9 As Label
    Friend WithEvents btnT12Pointerssn As Button
    Friend WithEvents btnT12Pointerssp As Button
    Friend WithEvents Label12 As Label
    Friend WithEvents btnT22Pointerssn As Button
    Friend WithEvents btnT22Pointerssp As Button
    Friend WithEvents Label13 As Label
    Friend WithEvents btnT23Pointerssn As Button
    Friend WithEvents btnT23Pointerssp As Button
    Friend WithEvents Label14 As Label
    Friend WithEvents btnT2FreeThrowssn As Button
    Friend WithEvents btnT2FreeThrowssp As Button
    Friend WithEvents Label15 As Label
    Friend WithEvents btnQTR As Button
End Class
