﻿Public Class Controller
    Private Sub Controller_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    'Miscellaneous controls

    Private Sub btnStart_Click(sender As Object, e As EventArgs) Handles btnStart.Click
        Form1.tmrMainClock.Start()
    End Sub

    Private Sub btnStop_Click(sender As Object, e As EventArgs) Handles btnStop.Click
        Form1.tmrMainClock.Stop()
    End Sub

    Private Sub btnReset_Click(sender As Object, e As EventArgs)
        Form1.currenttime = 600
        Form1.lblMainClock.Text = Form1.currenttime

        Form1.RenderClock()
    End Sub
    Private Sub btnChangeTMs_Click(sender As Object, e As EventArgs) Handles btnChangeTMs.Click
        SetTeams.ShowDialog(Me)
    End Sub

    Private Sub btnStadium_Click(sender As Object, e As EventArgs) Handles btnStadium.Click
        SetStadium.ShowDialog(Me)
    End Sub

    Private Sub btnCloseController_Click(sender As Object, e As EventArgs) Handles btnCloseController.Click 'When clicked, closes the controller
        Me.Close()
        Me.Dispose()
    End Sub

    Private Sub btnQTR_Click(sender As Object, e As EventArgs) Handles btnQTR.Click
        Form1.lblQTR.Text = Val(Form1.lblQTR.Text) + 1
        If Form1.lblQTR.Text > 4 Then
            Form1.lblQTR.Text = 1
        End If
    End Sub







    'Team A controls
    Private Sub btnT1Sp1_Click(sender As Object, e As EventArgs) Handles btnT1Sp1.Click 'Score +1
        Dim Answer As String
        Form1.lblT1pnts.Text = Val(Form1.lblT1pnts.Text) + 1

        Answer = MsgBox("Was this a freethrow? This will add a score to 'Free throws' too", vbQuestion + vbYesNo, "Controller") 'Prompts a MsgBox if it was a free throw and will automatically add an integer under 'Free throws' if selected yes
        If Answer = vbYes Then
            Form1.lblFreeThrowsT1.Text = Val(Form1.lblFreeThrowsT1.Text) + 1
        End If
    End Sub
    Private Sub btnT1Sn1_Click(sender As Object, e As EventArgs) Handles btnT1Sn1.Click 'Score -1
        Dim Answer As String

        Form1.lblT1pnts.Text = Val(Form1.lblT1pnts.Text) - 1
        If Form1.lblT1pnts.Text < 0 Then
            Form1.lblT1pnts.Text = 0
        End If

        If Form1.lblFreeThrowsT1.Text <= 0 Then
            Form1.lblFreeThrowsT1.Text = 0
        Else
            Answer = MsgBox("Would you like to remove a point from 'Free throws' too?", vbQuestion + vbYesNo, "Controller") 'Prompts a MsgBox if you would like to remove a point from 'Free throws' and will remove an integer if selected yes
            If Answer = vbYes Then
                Form1.lblFreeThrowsT1.Text = Val(Form1.lblFreeThrowsT1.Text) - 1
            End If
        End If
    End Sub
    Private Sub btnT1Sp2_Click(sender As Object, e As EventArgs) Handles btnT1Sp2.Click 'Score +2
        Dim Answer As String
        Form1.lblT1pnts.Text = Val(Form1.lblT1pnts.Text) + 2

        Answer = MsgBox("Was this a 2-Pointer? This will add a score to '2-Pointers' too", vbQuestion + vbYesNo, "Controller") 'Prompts a MsgBox if it was a 2-Pointer and will automatically add an integer under '2-Pointers' if selected yes
        If Answer = vbYes Then
            Form1.lbl2PointersT1.Text = Val(Form1.lbl2PointersT1.Text) + 1
        End If
    End Sub
    Private Sub btnT1Sn2_Click(sender As Object, e As EventArgs) Handles btnT1Sn2.Click 'Score -2
        Dim Answer As String

        Form1.lblT1pnts.Text = Val(Form1.lblT1pnts.Text) - 2
        If Form1.lblT1pnts.Text < 0 Then
            Form1.lblT1pnts.Text = 0
        End If

        If Form1.lbl2PointersT1.Text <= 0 Then
            Form1.lbl2PointersT1.Text = 0
        Else
            Answer = MsgBox("Would you like to remove a point from '2-Pointers' too?", vbQuestion + vbYesNo, "Controller") 'Prompts a MsgBox if you would like to remove a point from '2-Pointers' and will remove an integer if selected yes
            If Answer = vbYes Then
                Form1.lbl2PointersT1.Text = Val(Form1.lbl2PointersT1.Text) - 1
            End If
        End If
    End Sub
    Private Sub btnT1Sp3_Click(sender As Object, e As EventArgs) Handles btnT1Sp3.Click 'Score +3
        Dim Answer As String
        Form1.lblT1pnts.Text = Val(Form1.lblT1pnts.Text) + 3

        Answer = MsgBox("Was this a 3-Pointer? This will add a score to '3-Pointers' too", vbQuestion + vbYesNo, "Controller") 'Prompts a MsgBox if it was a 3-Pointer and will automatically add an integer under '3-Pointers' if selected yes
        If Answer = vbYes Then
            Form1.lbl3PointersT1.Text = Val(Form1.lbl3PointersT1.Text) + 1
        End If
    End Sub

    Private Sub btnT1Sn3_Click(sender As Object, e As EventArgs) Handles btnT1Sn3.Click 'Score -3
        Dim Answer As String

        Form1.lblT1pnts.Text = Val(Form1.lblT1pnts.Text) - 2
        If Form1.lblT1pnts.Text < 0 Then
            Form1.lblT1pnts.Text = 0
        End If

        If Form1.lbl3PointersT1.Text <= 0 Then
            Form1.lbl3PointersT1.Text = 0
        Else
            Answer = MsgBox("Would you like to remove a point from '3-Pointers' too?", vbQuestion + vbYesNo, "Controller") 'Prompts a MsgBox if you would like to remove a point from '3-Pointers' and will remove an integer if selected yes
            If Answer = vbYes Then
                Form1.lbl3PointersT1.Text = Val(Form1.lbl3PointersT1.Text) - 1
            End If
        End If
    End Sub

    Private Sub btnT1Foulsp_Click(sender As Object, e As EventArgs) Handles btnT1Foulsp.Click 'Fouls +1
        Form1.lblFoulsT1.Text = Val(Form1.lblFoulsT1.Text) + 1
    End Sub

    Private Sub btnT1Foulsn_Click(sender As Object, e As EventArgs) Handles btnT1Foulsn.Click 'Fouls -1
        Form1.lblFoulsT1.Text = Val(Form1.lblFoulsT1.Text) - 1
        If Form1.lblFoulsT1.Text < 0 Then
            Form1.lblFoulsT1.Text = 0
        End If
    End Sub

    Private Sub btnT1Blocksp_Click(sender As Object, e As EventArgs) Handles btnT1Blocksp.Click 'Blocks +1
        Form1.lblBlocksT1.Text = Val(Form1.lblBlocksT1.Text) + 1
    End Sub

    Private Sub btnT1Blocksn_Click(sender As Object, e As EventArgs) Handles btnT1Blocksn.Click 'Blocks -1
        Form1.lblBlocksT1.Text = Val(Form1.lblBlocksT1.Text) - 1
        If Form1.lblBlocksT1.Text < 0 Then
            Form1.lblBlocksT1.Text = 0
        End If
    End Sub

    Private Sub btnT1Stealsp_Click(sender As Object, e As EventArgs) Handles btnT1Stealsp.Click 'Steals +1
        Form1.lblStealsT1.Text = Val(Form1.lblStealsT1.Text) + 1
    End Sub

    Private Sub btnT1Stealsn_Click(sender As Object, e As EventArgs) Handles btnT1Stealsn.Click 'Steals -1
        Form1.lblStealsT1.Text = Val(Form1.lblStealsT1.Text) - 1
        If Form1.lblStealsT1.Text < 0 Then
            Form1.lblStealsT1.Text = 0
        End If
    End Sub
    Private Sub btnT1FreeThrowssp_Click(sender As Object, e As EventArgs) Handles btnT1FreeThrowssp.Click 'Free throws +1
        Form1.lblFreeThrowsT1.Text = Val(Form1.lblFreeThrowsT1.Text) + 1
    End Sub

    Private Sub btnT1FreeThrowssn_Click(sender As Object, e As EventArgs) Handles btnT1FreeThrowssn.Click 'Free throws -1
        Form1.lblFreeThrowsT1.Text = Val(Form1.lblFreeThrowsT1.Text) - 1
        If Form1.lblFreeThrowsT1.Text < 0 Then
            Form1.lblFreeThrowsT1.Text = 0
        End If
    End Sub

    Private Sub btnT12Pointerssp_Click(sender As Object, e As EventArgs) Handles btnT12Pointerssp.Click '2 Pointers +1
        Form1.lbl2PointersT1.Text = Val(Form1.lbl2PointersT1.Text) + 1
    End Sub

    Private Sub btnT12Pointerssn_Click(sender As Object, e As EventArgs) Handles btnT12Pointerssn.Click '2 Pointers -1
        Form1.lbl2PointersT1.Text = Val(Form1.lbl2PointersT1.Text) - 1
        If Form1.lbl2PointersT1.Text < 0 Then
            Form1.lbl2PointersT1.Text = 0
        End If
    End Sub

    Private Sub btnT13Pointerssp_Click(sender As Object, e As EventArgs) Handles btnT13Pointerssp.Click '3 Pointers +1
        Form1.lbl3PointersT1.Text = Val(Form1.lbl3PointersT1.Text) + 1
    End Sub

    Private Sub btnT13Pointerssn_Click(sender As Object, e As EventArgs) Handles btnT13Pointerssn.Click '3 Pointers -1
        Form1.lbl3PointersT1.Text = Val(Form1.lbl3PointersT1.Text) - 1
        If Form1.lbl3PointersT1.Text < 0 Then
            Form1.lbl3PointersT1.Text = 0
        End If
    End Sub









    'Team B controls
    Private Sub btnT2Sp1_Click(sender As Object, e As EventArgs) Handles btnT2Sp1.Click 'Score +1
        Dim Answer As String
        Form1.lblT2pnts.Text = Val(Form1.lblT2pnts.Text) + 1

        Answer = MsgBox("Was this a freethrow? This will add a score to 'Free throws' too", vbQuestion + vbYesNo, "Controller") 'Prompts a MsgBox if it was a free throw and will automatically add an integer under 'Free throws' if selected yes
        If Answer = vbYes Then
            Form1.lblFreeThrowsT2.Text = Val(Form1.lblFreeThrowsT2.Text) + 1
        End If
    End Sub

    Private Sub btnT2Sn1_Click(sender As Object, e As EventArgs) Handles btnT2Sn1.Click 'Score -1
        Dim Answer As String

        Form1.lblT2pnts.Text = Val(Form1.lblT2pnts.Text) - 1
        If Form1.lblT2pnts.Text < 0 Then
            Form1.lblT2pnts.Text = 0
        End If

        If Form1.lblFreeThrowsT2.Text <= 0 Then
            Form1.lblFreeThrowsT2.Text = 0
        Else
            Answer = MsgBox("Would you like to remove a point from 'Free throws' too?", vbQuestion + vbYesNo, "Controller") 'Prompts a MsgBox if you would like to remove a point from 'Free throws' and will remove an integer if selected yes
            If Answer = vbYes Then
                Form1.lblFreeThrowsT2.Text = Val(Form1.lblFreeThrowsT2.Text) - 1
            End If
        End If
    End Sub

    Private Sub btnT2Sp2_Click(sender As Object, e As EventArgs) Handles btnT2Sp2.Click 'Score +2
        Dim Answer As String
        Form1.lblT2pnts.Text = Val(Form1.lblT2pnts.Text) + 2

        Answer = MsgBox("Was this a 2-Pointer? This will add a score to '2-Pointers' too", vbQuestion + vbYesNo, "Controller") 'Prompts a MsgBox if it was a 2-Pointer and will automatically add an integer under '2-Pointers' if selected yes
        If Answer = vbYes Then
            Form1.lbl2PointersT2.Text = Val(Form1.lbl2PointersT2.Text) + 1
        End If
    End Sub

    Private Sub btnT2Sn2_Click(sender As Object, e As EventArgs) Handles btnT2Sn2.Click 'Score -2
        Dim Answer As String

        Form1.lblT2pnts.Text = Val(Form1.lblT2pnts.Text) - 2
        If Form1.lblT2pnts.Text < 0 Then
            Form1.lblT2pnts.Text = 0
        End If

        If Form1.lbl2PointersT2.Text <= 0 Then
            Form1.lbl2PointersT2.Text = 0
        Else
            Answer = MsgBox("Would you like to remove a point from '2-Pointers' too?", vbQuestion + vbYesNo, "Controller") 'Prompts a MsgBox if you would like to remove a point from '2-Pointers' and will remove an integer if selected yes
            If Answer = vbYes Then
                Form1.lbl2PointersT2.Text = Val(Form1.lbl2PointersT2.Text) - 1
            End If
        End If
    End Sub

    Private Sub btnT2Sp3_Click(sender As Object, e As EventArgs) Handles btnT2Sp3.Click 'Score +3
        Dim Answer As String
        Form1.lblT2pnts.Text = Val(Form1.lblT2pnts.Text) + 3

        Answer = MsgBox("Was this a 2-Pointer? This will add a score to '3-Pointers' too", vbQuestion + vbYesNo, "Controller") 'Prompts a MsgBox if it was a 3-Pointer and will automatically add an integer under '3-Pointers' if selected yes
        If Answer = vbYes Then
            Form1.lbl3PointersT2.Text = Val(Form1.lbl3PointersT2.Text) + 1
        End If
    End Sub

    Private Sub btnT2Sn3_Click(sender As Object, e As EventArgs) Handles btnT2Sn3.Click 'Score -3
        Dim Answer As String

        Form1.lblT2pnts.Text = Val(Form1.lblT2pnts.Text) - 2
        If Form1.lblT2pnts.Text < 0 Then
            Form1.lblT2pnts.Text = 0
        End If

        If Form1.lbl3PointersT2.Text <= 0 Then
            Form1.lbl3PointersT2.Text = 0
        Else
            Answer = MsgBox("Would you like to remove a point from '3-Pointers' too?", vbQuestion + vbYesNo, "Controller") 'Prompts a MsgBox if you would like to remove a point from '3-Pointers' and will remove an integer if selected yes
            If Answer = vbYes Then
                Form1.lbl3PointersT2.Text = Val(Form1.lbl3PointersT2.Text) - 1
            End If
        End If
    End Sub

    Private Sub btnT2Foulsp_Click(sender As Object, e As EventArgs) Handles btnT2Foulsp.Click 'Fouls +1
        Form1.lblFoulsT2.Text = Val(Form1.lblFoulsT2.Text) + 1
    End Sub

    Private Sub btnT2Foulsn_Click(sender As Object, e As EventArgs) Handles btnT2Foulsn.Click 'Fouls -1
        Form1.lblFoulsT2.Text = Val(Form1.lblFoulsT2.Text) - 1
        If Form1.lblFoulsT2.Text < 0 Then
            Form1.lblFoulsT2.Text = 0
        End If
    End Sub

    Private Sub btnT2Blockssp_Click(sender As Object, e As EventArgs) Handles btnT2Blockssp.Click 'Blocks +1
        Form1.lblBlocksT2.Text = Val(Form1.lblBlocksT2.Text) + 1
    End Sub

    Private Sub btnT2Blockssn_Click(sender As Object, e As EventArgs) Handles btnT2Blockssn.Click 'Blocks -1
        Form1.lblBlocksT2.Text = Val(Form1.lblBlocksT2.Text) - 1
        If Form1.lblBlocksT2.Text < 0 Then
            Form1.lblBlocksT2.Text = 0
        End If
    End Sub

    Private Sub btnT2Stealssp_Click(sender As Object, e As EventArgs) Handles btnT2Stealssp.Click 'Steals +1
        Form1.lblStealsT2.Text = Val(Form1.lblStealsT2.Text) + 1
    End Sub

    Private Sub btnT2Stealssn_Click(sender As Object, e As EventArgs) Handles btnT2Stealssn.Click 'Steals -1
        Form1.lblStealsT2.Text = Val(Form1.lblStealsT2.Text) - 1
        If Form1.lblStealsT2.Text < 0 Then
            Form1.lblStealsT2.Text = 0
        End If
    End Sub

    Private Sub btnT2FreeThrowssp_Click(sender As Object, e As EventArgs) Handles btnT2FreeThrowssp.Click 'Free throws +1
        Form1.lblFreeThrowsT2.Text = Val(Form1.lblFreeThrowsT2.Text) + 1
    End Sub

    Private Sub btnT2FreeThrowssn_Click(sender As Object, e As EventArgs) Handles btnT2FreeThrowssn.Click 'Free throws -1
        Form1.lblFreeThrowsT2.Text = Val(Form1.lblFreeThrowsT2.Text) - 1
        If Form1.lblFreeThrowsT2.Text < 0 Then
            Form1.lblFreeThrowsT2.Text = 0
        End If
    End Sub

    Private Sub btnT22Pointerssp_Click(sender As Object, e As EventArgs) Handles btnT22Pointerssp.Click '2-Pointers +1
        Form1.lbl2PointersT2.Text = Val(Form1.lbl2PointersT2.Text) + 1
    End Sub

    Private Sub btnT22Pointerssn_Click(sender As Object, e As EventArgs) Handles btnT22Pointerssn.Click '2-Pointers -1
        Form1.lbl2PointersT2.Text = Val(Form1.lbl2PointersT2.Text) - 1
        If Form1.lbl2PointersT2.Text < 0 Then
            Form1.lbl2PointersT2.Text = 0
        End If
    End Sub

    Private Sub btnT23Pointerssp_Click(sender As Object, e As EventArgs) Handles btnT23Pointerssp.Click '3-Pointers +1
        Form1.lbl3PointersT2.Text = Val(Form1.lbl3PointersT2.Text) + 1
    End Sub

    Private Sub btnT23Pointerssn_Click(sender As Object, e As EventArgs) Handles btnT23Pointerssn.Click '3-Pointers -1
        If Form1.lbl3PointersT2.Text < 0 Then
            Form1.lbl3PointersT2.Text = 0
        End If
    End Sub
End Class
