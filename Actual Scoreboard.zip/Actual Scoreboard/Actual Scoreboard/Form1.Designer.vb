﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.lblHomeTM = New System.Windows.Forms.Label()
        Me.lblAwayTM = New System.Windows.Forms.Label()
        Me.lblT1pnts = New System.Windows.Forms.Label()
        Me.lblT2pnts = New System.Windows.Forms.Label()
        Me.lblFoulHT = New System.Windows.Forms.Label()
        Me.lblFoulsT1 = New System.Windows.Forms.Label()
        Me.lblStealsT1 = New System.Windows.Forms.Label()
        Me.lblBlocksT1 = New System.Windows.Forms.Label()
        Me.lbl3PointersT1 = New System.Windows.Forms.Label()
        Me.lblStealsHT = New System.Windows.Forms.Label()
        Me.lblBlocksHT = New System.Windows.Forms.Label()
        Me.lbl3pointersHT = New System.Windows.Forms.Label()
        Me.lblBlocksAT = New System.Windows.Forms.Label()
        Me.lblStealsAT = New System.Windows.Forms.Label()
        Me.lblBlocksT2 = New System.Windows.Forms.Label()
        Me.lblStealsT2 = New System.Windows.Forms.Label()
        Me.lblFoulsT2 = New System.Windows.Forms.Label()
        Me.lblFoulsAT = New System.Windows.Forms.Label()
        Me.lblMainClock = New System.Windows.Forms.Label()
        Me.tmrMainClock = New System.Windows.Forms.Timer(Me.components)
        Me.lblQTR = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.lblStadium = New System.Windows.Forms.Label()
        Me.btnShowController = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.lblFreeThrowsT1 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.lbl2PointersT1 = New System.Windows.Forms.Label()
        Me.lbl2pointerAT = New System.Windows.Forms.Label()
        Me.lbl2PointersT2 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.lblFreeThrowsT2 = New System.Windows.Forms.Label()
        Me.lbl3pointerAT = New System.Windows.Forms.Label()
        Me.lbl3PointersT2 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'lblHomeTM
        '
        Me.lblHomeTM.AutoSize = True
        Me.lblHomeTM.Font = New System.Drawing.Font("Segoe UI", 27.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.lblHomeTM.Location = New System.Drawing.Point(142, 9)
        Me.lblHomeTM.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblHomeTM.Name = "lblHomeTM"
        Me.lblHomeTM.Size = New System.Drawing.Size(140, 48)
        Me.lblHomeTM.TabIndex = 0
        Me.lblHomeTM.Text = "Team 1"
        '
        'lblAwayTM
        '
        Me.lblAwayTM.AutoSize = True
        Me.lblAwayTM.Font = New System.Drawing.Font("Segoe UI", 27.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.lblAwayTM.Location = New System.Drawing.Point(1102, 9)
        Me.lblAwayTM.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblAwayTM.Name = "lblAwayTM"
        Me.lblAwayTM.Size = New System.Drawing.Size(140, 48)
        Me.lblAwayTM.TabIndex = 1
        Me.lblAwayTM.Text = "Team 2"
        '
        'lblT1pnts
        '
        Me.lblT1pnts.Font = New System.Drawing.Font("Segoe UI", 48.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.lblT1pnts.Location = New System.Drawing.Point(178, 35)
        Me.lblT1pnts.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblT1pnts.Name = "lblT1pnts"
        Me.lblT1pnts.Size = New System.Drawing.Size(74, 73)
        Me.lblT1pnts.TabIndex = 3
        Me.lblT1pnts.Text = "0"
        '
        'lblT2pnts
        '
        Me.lblT2pnts.Font = New System.Drawing.Font("Segoe UI", 48.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.lblT2pnts.Location = New System.Drawing.Point(1135, 35)
        Me.lblT2pnts.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblT2pnts.Name = "lblT2pnts"
        Me.lblT2pnts.Size = New System.Drawing.Size(74, 73)
        Me.lblT2pnts.TabIndex = 4
        Me.lblT2pnts.Text = "0"
        '
        'lblFoulHT
        '
        Me.lblFoulHT.AutoSize = True
        Me.lblFoulHT.Font = New System.Drawing.Font("Segoe UI", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.lblFoulHT.Location = New System.Drawing.Point(160, 135)
        Me.lblFoulHT.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblFoulHT.Name = "lblFoulHT"
        Me.lblFoulHT.Size = New System.Drawing.Size(95, 45)
        Me.lblFoulHT.TabIndex = 7
        Me.lblFoulHT.Text = "Fouls"
        '
        'lblFoulsT1
        '
        Me.lblFoulsT1.AutoSize = True
        Me.lblFoulsT1.Font = New System.Drawing.Font("Segoe UI", 20.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.lblFoulsT1.Location = New System.Drawing.Point(195, 172)
        Me.lblFoulsT1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblFoulsT1.Name = "lblFoulsT1"
        Me.lblFoulsT1.Size = New System.Drawing.Size(33, 37)
        Me.lblFoulsT1.TabIndex = 11
        Me.lblFoulsT1.Text = "0"
        '
        'lblStealsT1
        '
        Me.lblStealsT1.AutoSize = True
        Me.lblStealsT1.Font = New System.Drawing.Font("Segoe UI", 20.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.lblStealsT1.Location = New System.Drawing.Point(195, 316)
        Me.lblStealsT1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblStealsT1.Name = "lblStealsT1"
        Me.lblStealsT1.Size = New System.Drawing.Size(33, 37)
        Me.lblStealsT1.TabIndex = 12
        Me.lblStealsT1.Text = "0"
        '
        'lblBlocksT1
        '
        Me.lblBlocksT1.AutoSize = True
        Me.lblBlocksT1.Font = New System.Drawing.Font("Segoe UI", 20.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.lblBlocksT1.Location = New System.Drawing.Point(195, 241)
        Me.lblBlocksT1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblBlocksT1.Name = "lblBlocksT1"
        Me.lblBlocksT1.Size = New System.Drawing.Size(33, 37)
        Me.lblBlocksT1.TabIndex = 13
        Me.lblBlocksT1.Text = "0"
        '
        'lbl3PointersT1
        '
        Me.lbl3PointersT1.AutoSize = True
        Me.lbl3PointersT1.Font = New System.Drawing.Font("Segoe UI", 20.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.lbl3PointersT1.Location = New System.Drawing.Point(194, 434)
        Me.lbl3PointersT1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lbl3PointersT1.Name = "lbl3PointersT1"
        Me.lbl3PointersT1.Size = New System.Drawing.Size(33, 37)
        Me.lbl3PointersT1.TabIndex = 14
        Me.lbl3PointersT1.Text = "0"
        '
        'lblStealsHT
        '
        Me.lblStealsHT.AutoSize = True
        Me.lblStealsHT.Font = New System.Drawing.Font("Segoe UI", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.lblStealsHT.Location = New System.Drawing.Point(160, 278)
        Me.lblStealsHT.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblStealsHT.Name = "lblStealsHT"
        Me.lblStealsHT.Size = New System.Drawing.Size(102, 45)
        Me.lblStealsHT.TabIndex = 15
        Me.lblStealsHT.Text = "Steals"
        '
        'lblBlocksHT
        '
        Me.lblBlocksHT.AutoSize = True
        Me.lblBlocksHT.Font = New System.Drawing.Font("Segoe UI", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.lblBlocksHT.Location = New System.Drawing.Point(160, 205)
        Me.lblBlocksHT.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblBlocksHT.Name = "lblBlocksHT"
        Me.lblBlocksHT.Size = New System.Drawing.Size(110, 45)
        Me.lblBlocksHT.TabIndex = 16
        Me.lblBlocksHT.Text = "Blocks"
        '
        'lbl3pointersHT
        '
        Me.lbl3pointersHT.AutoSize = True
        Me.lbl3pointersHT.Font = New System.Drawing.Font("Segoe UI", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.lbl3pointersHT.Location = New System.Drawing.Point(121, 398)
        Me.lbl3pointersHT.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lbl3pointersHT.Name = "lbl3pointersHT"
        Me.lbl3pointersHT.Size = New System.Drawing.Size(165, 45)
        Me.lbl3pointersHT.TabIndex = 17
        Me.lbl3pointersHT.Text = "3-Pointers"
        '
        'lblBlocksAT
        '
        Me.lblBlocksAT.AutoSize = True
        Me.lblBlocksAT.Font = New System.Drawing.Font("Segoe UI", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.lblBlocksAT.Location = New System.Drawing.Point(1117, 205)
        Me.lblBlocksAT.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblBlocksAT.Name = "lblBlocksAT"
        Me.lblBlocksAT.Size = New System.Drawing.Size(110, 45)
        Me.lblBlocksAT.TabIndex = 24
        Me.lblBlocksAT.Text = "Blocks"
        '
        'lblStealsAT
        '
        Me.lblStealsAT.AutoSize = True
        Me.lblStealsAT.Font = New System.Drawing.Font("Segoe UI", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.lblStealsAT.Location = New System.Drawing.Point(1117, 278)
        Me.lblStealsAT.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblStealsAT.Name = "lblStealsAT"
        Me.lblStealsAT.Size = New System.Drawing.Size(102, 45)
        Me.lblStealsAT.TabIndex = 23
        Me.lblStealsAT.Text = "Steals"
        '
        'lblBlocksT2
        '
        Me.lblBlocksT2.AutoSize = True
        Me.lblBlocksT2.Font = New System.Drawing.Font("Segoe UI", 20.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.lblBlocksT2.Location = New System.Drawing.Point(1152, 316)
        Me.lblBlocksT2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblBlocksT2.Name = "lblBlocksT2"
        Me.lblBlocksT2.Size = New System.Drawing.Size(33, 37)
        Me.lblBlocksT2.TabIndex = 21
        Me.lblBlocksT2.Text = "0"
        '
        'lblStealsT2
        '
        Me.lblStealsT2.AutoSize = True
        Me.lblStealsT2.Font = New System.Drawing.Font("Segoe UI", 20.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.lblStealsT2.Location = New System.Drawing.Point(1152, 241)
        Me.lblStealsT2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblStealsT2.Name = "lblStealsT2"
        Me.lblStealsT2.Size = New System.Drawing.Size(33, 37)
        Me.lblStealsT2.TabIndex = 20
        Me.lblStealsT2.Text = "0"
        '
        'lblFoulsT2
        '
        Me.lblFoulsT2.AutoSize = True
        Me.lblFoulsT2.Font = New System.Drawing.Font("Segoe UI", 20.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.lblFoulsT2.Location = New System.Drawing.Point(1152, 172)
        Me.lblFoulsT2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblFoulsT2.Name = "lblFoulsT2"
        Me.lblFoulsT2.Size = New System.Drawing.Size(33, 37)
        Me.lblFoulsT2.TabIndex = 19
        Me.lblFoulsT2.Text = "0"
        '
        'lblFoulsAT
        '
        Me.lblFoulsAT.AutoSize = True
        Me.lblFoulsAT.Font = New System.Drawing.Font("Segoe UI", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.lblFoulsAT.Location = New System.Drawing.Point(1117, 135)
        Me.lblFoulsAT.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblFoulsAT.Name = "lblFoulsAT"
        Me.lblFoulsAT.Size = New System.Drawing.Size(95, 45)
        Me.lblFoulsAT.TabIndex = 18
        Me.lblFoulsAT.Text = "Fouls"
        '
        'lblMainClock
        '
        Me.lblMainClock.Font = New System.Drawing.Font("Segoe UI", 86.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.lblMainClock.Location = New System.Drawing.Point(447, -20)
        Me.lblMainClock.Name = "lblMainClock"
        Me.lblMainClock.Size = New System.Drawing.Size(525, 128)
        Me.lblMainClock.TabIndex = 26
        Me.lblMainClock.Text = "00:00:00"
        Me.lblMainClock.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'tmrMainClock
        '
        Me.tmrMainClock.Interval = 1000
        '
        'lblQTR
        '
        Me.lblQTR.AutoSize = True
        Me.lblQTR.Font = New System.Drawing.Font("Segoe UI", 36.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.lblQTR.Location = New System.Drawing.Point(685, 316)
        Me.lblQTR.Name = "lblQTR"
        Me.lblQTR.Size = New System.Drawing.Size(56, 65)
        Me.lblQTR.TabIndex = 29
        Me.lblQTR.Text = "1"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Segoe UI", 26.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label7.Location = New System.Drawing.Point(640, 276)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(138, 47)
        Me.Label7.TabIndex = 30
        Me.Label7.Text = "Quarter"
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Segoe UI", 26.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label8.Location = New System.Drawing.Point(631, 140)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(147, 47)
        Me.Label8.TabIndex = 31
        Me.Label8.Text = "Stadium"
        Me.Label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblStadium
        '
        Me.lblStadium.AutoSize = True
        Me.lblStadium.Font = New System.Drawing.Font("Segoe UI", 36.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.lblStadium.Location = New System.Drawing.Point(589, 178)
        Me.lblStadium.Name = "lblStadium"
        Me.lblStadium.Size = New System.Drawing.Size(245, 65)
        Me.lblStadium.TabIndex = 32
        Me.lblStadium.Text = "STADIUM"
        Me.lblStadium.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'btnShowController
        '
        Me.btnShowController.Font = New System.Drawing.Font("Segoe UI", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.btnShowController.Location = New System.Drawing.Point(589, 580)
        Me.btnShowController.Name = "btnShowController"
        Me.btnShowController.Size = New System.Drawing.Size(266, 136)
        Me.btnShowController.TabIndex = 37
        Me.btnShowController.Text = "Show Controller"
        Me.btnShowController.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("Segoe UI", 26.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label1.Location = New System.Drawing.Point(1, 91)
        Me.Label1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(1354, 44)
        Me.Label1.TabIndex = 38
        Me.Label1.Text = "---------------------------------------------------------------------------------" &
    "--------------------------" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        '
        'Label4
        '
        Me.Label4.Font = New System.Drawing.Font("Segoe UI", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label4.Location = New System.Drawing.Point(420, 5)
        Me.Label4.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(22, 749)
        Me.Label4.TabIndex = 76
        Me.Label4.Text = "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) &
    "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        '
        'Label5
        '
        Me.Label5.Font = New System.Drawing.Font("Segoe UI", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label5.Location = New System.Drawing.Point(969, 5)
        Me.Label5.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(22, 749)
        Me.Label5.TabIndex = 77
        Me.Label5.Text = "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) &
    "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Segoe UI", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label2.Location = New System.Drawing.Point(121, 544)
        Me.Label2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(186, 45)
        Me.Label2.TabIndex = 79
        Me.Label2.Text = "Free throws"
        '
        'lblFreeThrowsT1
        '
        Me.lblFreeThrowsT1.AutoSize = True
        Me.lblFreeThrowsT1.Font = New System.Drawing.Font("Segoe UI", 20.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.lblFreeThrowsT1.Location = New System.Drawing.Point(194, 580)
        Me.lblFreeThrowsT1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblFreeThrowsT1.Name = "lblFreeThrowsT1"
        Me.lblFreeThrowsT1.Size = New System.Drawing.Size(33, 37)
        Me.lblFreeThrowsT1.TabIndex = 78
        Me.lblFreeThrowsT1.Text = "0"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Segoe UI", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label6.Location = New System.Drawing.Point(121, 471)
        Me.Label6.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(165, 45)
        Me.Label6.TabIndex = 81
        Me.Label6.Text = "2-Pointers"
        '
        'lbl2PointersT1
        '
        Me.lbl2PointersT1.AutoSize = True
        Me.lbl2PointersT1.Font = New System.Drawing.Font("Segoe UI", 20.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.lbl2PointersT1.Location = New System.Drawing.Point(194, 507)
        Me.lbl2PointersT1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lbl2PointersT1.Name = "lbl2PointersT1"
        Me.lbl2PointersT1.Size = New System.Drawing.Size(33, 37)
        Me.lbl2PointersT1.TabIndex = 80
        Me.lbl2PointersT1.Text = "0"
        '
        'lbl2pointerAT
        '
        Me.lbl2pointerAT.AutoSize = True
        Me.lbl2pointerAT.Font = New System.Drawing.Font("Segoe UI", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.lbl2pointerAT.Location = New System.Drawing.Point(1079, 471)
        Me.lbl2pointerAT.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lbl2pointerAT.Name = "lbl2pointerAT"
        Me.lbl2pointerAT.Size = New System.Drawing.Size(165, 45)
        Me.lbl2pointerAT.TabIndex = 87
        Me.lbl2pointerAT.Text = "2-Pointers"
        '
        'lbl2PointersT2
        '
        Me.lbl2PointersT2.AutoSize = True
        Me.lbl2PointersT2.Font = New System.Drawing.Font("Segoe UI", 20.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.lbl2PointersT2.Location = New System.Drawing.Point(1152, 507)
        Me.lbl2PointersT2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lbl2PointersT2.Name = "lbl2PointersT2"
        Me.lbl2PointersT2.Size = New System.Drawing.Size(33, 37)
        Me.lbl2PointersT2.TabIndex = 86
        Me.lbl2PointersT2.Text = "0"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Segoe UI", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label12.Location = New System.Drawing.Point(1079, 544)
        Me.Label12.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(186, 45)
        Me.Label12.TabIndex = 85
        Me.Label12.Text = "Free throws"
        '
        'lblFreeThrowsT2
        '
        Me.lblFreeThrowsT2.AutoSize = True
        Me.lblFreeThrowsT2.Font = New System.Drawing.Font("Segoe UI", 20.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.lblFreeThrowsT2.Location = New System.Drawing.Point(1152, 580)
        Me.lblFreeThrowsT2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblFreeThrowsT2.Name = "lblFreeThrowsT2"
        Me.lblFreeThrowsT2.Size = New System.Drawing.Size(33, 37)
        Me.lblFreeThrowsT2.TabIndex = 84
        Me.lblFreeThrowsT2.Text = "0"
        '
        'lbl3pointerAT
        '
        Me.lbl3pointerAT.AutoSize = True
        Me.lbl3pointerAT.Font = New System.Drawing.Font("Segoe UI", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.lbl3pointerAT.Location = New System.Drawing.Point(1079, 398)
        Me.lbl3pointerAT.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lbl3pointerAT.Name = "lbl3pointerAT"
        Me.lbl3pointerAT.Size = New System.Drawing.Size(165, 45)
        Me.lbl3pointerAT.TabIndex = 83
        Me.lbl3pointerAT.Text = "3-Pointers"
        '
        'lbl3PointersT2
        '
        Me.lbl3PointersT2.AutoSize = True
        Me.lbl3PointersT2.Font = New System.Drawing.Font("Segoe UI", 20.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.lbl3PointersT2.Location = New System.Drawing.Point(1152, 434)
        Me.lbl3PointersT2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lbl3PointersT2.Name = "lbl3PointersT2"
        Me.lbl3PointersT2.Size = New System.Drawing.Size(33, 37)
        Me.lbl3PointersT2.TabIndex = 82
        Me.lbl3PointersT2.Text = "0"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1346, 732)
        Me.Controls.Add(Me.lblMainClock)
        Me.Controls.Add(Me.lbl2pointerAT)
        Me.Controls.Add(Me.lbl2PointersT2)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.lblFreeThrowsT2)
        Me.Controls.Add(Me.lbl3pointerAT)
        Me.Controls.Add(Me.lbl3PointersT2)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.lbl2PointersT1)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.lblFreeThrowsT1)
        Me.Controls.Add(Me.lblHomeTM)
        Me.Controls.Add(Me.lblT1pnts)
        Me.Controls.Add(Me.btnShowController)
        Me.Controls.Add(Me.lblStadium)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.lblQTR)
        Me.Controls.Add(Me.lblBlocksAT)
        Me.Controls.Add(Me.lblStealsAT)
        Me.Controls.Add(Me.lblBlocksT2)
        Me.Controls.Add(Me.lblStealsT2)
        Me.Controls.Add(Me.lblFoulsT2)
        Me.Controls.Add(Me.lblFoulsAT)
        Me.Controls.Add(Me.lbl3pointersHT)
        Me.Controls.Add(Me.lblBlocksHT)
        Me.Controls.Add(Me.lblStealsHT)
        Me.Controls.Add(Me.lblBlocksT1)
        Me.Controls.Add(Me.lblStealsT1)
        Me.Controls.Add(Me.lblFoulHT)
        Me.Controls.Add(Me.lblAwayTM)
        Me.Controls.Add(Me.lblT2pnts)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.lblFoulsT1)
        Me.Controls.Add(Me.lbl3PointersT1)
        Me.Margin = New System.Windows.Forms.Padding(2)
        Me.Name = "Form1"
        Me.Text = "Basketball Scoreboard - Yash, Hang, Fateh, Madit"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblHomeTM As Label
    Friend WithEvents lblAwayTM As Label
    Friend WithEvents lblT1pnts As Label
    Friend WithEvents lblT2pnts As Label
    Friend WithEvents lblFoulHT As Label
    Friend WithEvents lblFoulsT1 As Label
    Friend WithEvents lblStealsT1 As Label
    Friend WithEvents lblBlocksT1 As Label
    Friend WithEvents lbl3PointersT1 As Label
    Friend WithEvents lblStealsHT As Label
    Friend WithEvents lblBlocksHT As Label
    Friend WithEvents lbl3pointersHT As Label
    Friend WithEvents lblBlocksAT As Label
    Friend WithEvents lblStealsAT As Label
    Friend WithEvents lblBlocksT2 As Label
    Friend WithEvents lblStealsT2 As Label
    Friend WithEvents lblFoulsT2 As Label
    Friend WithEvents lblFoulsAT As Label
    Friend WithEvents lblMainClock As Label
    Friend WithEvents tmrMainClock As Timer
    Friend WithEvents lblQTR As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents lblStadium As Label
    Friend WithEvents btnShowController As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents lblFreeThrowsT1 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents lbl2PointersT1 As Label
    Friend WithEvents lbl2pointerAT As Label
    Friend WithEvents lbl2PointersT2 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents lblFreeThrowsT2 As Label
    Friend WithEvents lbl3pointerAT As Label
    Friend WithEvents lbl3PointersT2 As Label
End Class
