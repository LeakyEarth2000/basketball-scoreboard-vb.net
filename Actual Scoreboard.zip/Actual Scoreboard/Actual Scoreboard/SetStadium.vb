﻿Public Class SetStadium
    Private Sub SetStadium_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        tbStadiumName.Text = Form1.lblStadium.Text
    End Sub

    Private Sub btnStadiumOK_Click(sender As Object, e As EventArgs) Handles btnStadiumOK.Click
        If tbStadiumName.Text <> "" Then
            Form1.lblStadium.Text = UCase(tbStadiumName.Text)
        Else
            Form1.lblStadium.Text = "STADIUM"
        End If

        Me.Close()
        Me.Dispose()
    End Sub
End Class