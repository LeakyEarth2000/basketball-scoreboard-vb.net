﻿Public Class Form1
    Dim currenttime As Integer
    Dim MNTE As Integer
    Dim SCND As Integer
    Dim MS As Integer

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        currenttime = 600
        RenderClock()

        tmrClock.Stop()

        MNTE = 10
        SCND = 0
        MS = 0

        lblMainClockSS.Text = Format(MNTE, "00") & ":" & Format(SCND, "00")
        lblMainClockMS.Text = MS
    End Sub

    Private Sub btnShowController_Click(sender As Object, e As EventArgs) Handles btnShowController.Click
        Controller.ShowDialog(Me)
    End Sub
    Private Sub btnChangeTMs_Click(sender As Object, e As EventArgs) Handles btnChangeTMs.Click
        SetTeams.ShowDialog(Me)
    End Sub

    Private Sub btnEditTime_Click(sender As Object, e As EventArgs) Handles btnEditTime.Click
        Clock.ShowDialog(Me)
    End Sub

    Private Sub btnStadium_Click(sender As Object, e As EventArgs) Handles btnStadium.Click
        SetStadium.ShowDialog(Me)
    End Sub
    Private Sub btnStart_Click(sender As Object, e As EventArgs) Handles btnStart.Click
        tmrClock.Start()
    End Sub

    Private Sub btnStop_Click(sender As Object, e As EventArgs) Handles btnStop.Click
        tmrClock.Stop()
    End Sub

    Private Sub btnReset_Click(sender As Object, e As EventArgs) Handles btnReset.Click
        currenttime = 600
        lblMainClockSS.Text = currenttime

        RenderClock()
    End Sub

    Private Sub tmrClock_Tick(sender As Object, e As EventArgs) Handles tmrClock.Tick
        currenttime -= 1
        RenderClock()

        If currenttime = 0 Then
            MsgBox("Times up")
        End If

    End Sub


    Private Sub RenderClock()
        Dim timeOut As String
        Dim intMins, intsec As Integer
        intMins = currenttime \ 60
        intsec = currenttime Mod 60

        If intsec > 9 Then
            timeOut = $"{intMins}:{intsec}"
        Else
            timeOut = $"{intMins}:0{intsec}"
        End If
        lblMainClockSS.Text = timeOut
    End Sub

End Class
