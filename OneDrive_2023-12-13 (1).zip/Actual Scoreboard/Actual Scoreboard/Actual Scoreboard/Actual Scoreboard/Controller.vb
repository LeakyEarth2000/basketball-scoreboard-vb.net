﻿Public Class Controller
    Private Sub btnT1Foulsp_Click(sender As Object, e As EventArgs) Handles btnT1Foulsp.Click
        Form1.lblFouls.Text = Val(Form1.lblFouls.Text) + 1
    End Sub
End Class
