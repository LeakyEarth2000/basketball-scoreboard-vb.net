﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class SetTeams
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnOK = New System.Windows.Forms.Button()
        Me.lblHomeTM_ST = New System.Windows.Forms.Label()
        Me.lblAwayTM_ST = New System.Windows.Forms.Label()
        Me.tbHomeTM = New System.Windows.Forms.TextBox()
        Me.tbAwayTM = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'btnOK
        '
        Me.btnOK.Location = New System.Drawing.Point(94, 218)
        Me.btnOK.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.btnOK.Name = "btnOK"
        Me.btnOK.Size = New System.Drawing.Size(78, 28)
        Me.btnOK.TabIndex = 0
        Me.btnOK.Text = "OK"
        Me.btnOK.UseVisualStyleBackColor = True
        '
        'lblHomeTM_ST
        '
        Me.lblHomeTM_ST.AutoSize = True
        Me.lblHomeTM_ST.Location = New System.Drawing.Point(98, 28)
        Me.lblHomeTM_ST.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblHomeTM_ST.Name = "lblHomeTM_ST"
        Me.lblHomeTM_ST.Size = New System.Drawing.Size(71, 15)
        Me.lblHomeTM_ST.TabIndex = 1
        Me.lblHomeTM_ST.Text = "Home Team"
        '
        'lblAwayTM_ST
        '
        Me.lblAwayTM_ST.AutoSize = True
        Me.lblAwayTM_ST.Location = New System.Drawing.Point(102, 136)
        Me.lblAwayTM_ST.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblAwayTM_ST.Name = "lblAwayTM_ST"
        Me.lblAwayTM_ST.Size = New System.Drawing.Size(67, 15)
        Me.lblAwayTM_ST.TabIndex = 2
        Me.lblAwayTM_ST.Text = "Away Team"
        '
        'tbHomeTM
        '
        Me.tbHomeTM.Location = New System.Drawing.Point(80, 45)
        Me.tbHomeTM.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.tbHomeTM.Name = "tbHomeTM"
        Me.tbHomeTM.Size = New System.Drawing.Size(106, 23)
        Me.tbHomeTM.TabIndex = 3
        '
        'tbAwayTM
        '
        Me.tbAwayTM.Location = New System.Drawing.Point(80, 152)
        Me.tbAwayTM.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.tbAwayTM.Name = "tbAwayTM"
        Me.tbAwayTM.Size = New System.Drawing.Size(106, 23)
        Me.tbAwayTM.TabIndex = 4
        '
        'SetTeams
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(270, 270)
        Me.Controls.Add(Me.tbAwayTM)
        Me.Controls.Add(Me.tbHomeTM)
        Me.Controls.Add(Me.lblAwayTM_ST)
        Me.Controls.Add(Me.lblHomeTM_ST)
        Me.Controls.Add(Me.btnOK)
        Me.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.Name = "SetTeams"
        Me.Text = "SetTeams"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnOK As Button
    Friend WithEvents lblHomeTM_ST As Label
    Friend WithEvents lblAwayTM_ST As Label
    Friend WithEvents tbHomeTM As TextBox
    Friend WithEvents tbAwayTM As TextBox
End Class
