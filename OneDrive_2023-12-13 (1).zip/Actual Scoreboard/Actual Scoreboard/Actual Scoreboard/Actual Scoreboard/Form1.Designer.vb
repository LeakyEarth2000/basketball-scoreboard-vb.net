﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.lblHomeTM = New System.Windows.Forms.Label()
        Me.lblAwayTM = New System.Windows.Forms.Label()
        Me.btnChangeTMs = New System.Windows.Forms.Button()
        Me.lblHTpnts = New System.Windows.Forms.Label()
        Me.lblATpnts = New System.Windows.Forms.Label()
        Me.lblFoulHT = New System.Windows.Forms.Label()
        Me.lblFouls = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.lblStealsHT = New System.Windows.Forms.Label()
        Me.lblBlocksHT = New System.Windows.Forms.Label()
        Me.lbl3pointersHT = New System.Windows.Forms.Label()
        Me.lbl3pointersAT = New System.Windows.Forms.Label()
        Me.lblBlocksAT = New System.Windows.Forms.Label()
        Me.lblStealsAT = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.lblFoulsAT = New System.Windows.Forms.Label()
        Me.lblMainClockSS = New System.Windows.Forms.Label()
        Me.lblMainClockMS = New System.Windows.Forms.Label()
        Me.btnEditTime = New System.Windows.Forms.Button()
        Me.tmrClock = New System.Windows.Forms.Timer(Me.components)
        Me.lblQuarter = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.lblStadium = New System.Windows.Forms.Label()
        Me.btnStadium = New System.Windows.Forms.Button()
        Me.btnStart = New System.Windows.Forms.Button()
        Me.btnStop = New System.Windows.Forms.Button()
        Me.btnReset = New System.Windows.Forms.Button()
        Me.btnShowController = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'lblHomeTM
        '
        Me.lblHomeTM.AutoSize = True
        Me.lblHomeTM.Font = New System.Drawing.Font("Segoe UI", 27.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.lblHomeTM.Location = New System.Drawing.Point(134, 9)
        Me.lblHomeTM.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblHomeTM.Name = "lblHomeTM"
        Me.lblHomeTM.Size = New System.Drawing.Size(144, 48)
        Me.lblHomeTM.TabIndex = 0
        Me.lblHomeTM.Text = "Team A"
        '
        'lblAwayTM
        '
        Me.lblAwayTM.AutoSize = True
        Me.lblAwayTM.Font = New System.Drawing.Font("Segoe UI", 27.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.lblAwayTM.Location = New System.Drawing.Point(1043, 9)
        Me.lblAwayTM.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblAwayTM.Name = "lblAwayTM"
        Me.lblAwayTM.Size = New System.Drawing.Size(142, 48)
        Me.lblAwayTM.TabIndex = 1
        Me.lblAwayTM.Text = "Team B"
        '
        'btnChangeTMs
        '
        Me.btnChangeTMs.Location = New System.Drawing.Point(1219, 683)
        Me.btnChangeTMs.Margin = New System.Windows.Forms.Padding(2)
        Me.btnChangeTMs.Name = "btnChangeTMs"
        Me.btnChangeTMs.Size = New System.Drawing.Size(116, 50)
        Me.btnChangeTMs.TabIndex = 2
        Me.btnChangeTMs.Text = "Change Teams"
        Me.btnChangeTMs.UseVisualStyleBackColor = True
        '
        'lblHTpnts
        '
        Me.lblHTpnts.AutoSize = True
        Me.lblHTpnts.Font = New System.Drawing.Font("Segoe UI", 48.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.lblHTpnts.Location = New System.Drawing.Point(172, 35)
        Me.lblHTpnts.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblHTpnts.Name = "lblHTpnts"
        Me.lblHTpnts.Size = New System.Drawing.Size(74, 86)
        Me.lblHTpnts.TabIndex = 3
        Me.lblHTpnts.Text = "0"
        '
        'lblATpnts
        '
        Me.lblATpnts.AutoSize = True
        Me.lblATpnts.Font = New System.Drawing.Font("Segoe UI", 48.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.lblATpnts.Location = New System.Drawing.Point(1079, 35)
        Me.lblATpnts.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblATpnts.Name = "lblATpnts"
        Me.lblATpnts.Size = New System.Drawing.Size(74, 86)
        Me.lblATpnts.TabIndex = 4
        Me.lblATpnts.Text = "0"
        '
        'lblFoulHT
        '
        Me.lblFoulHT.AutoSize = True
        Me.lblFoulHT.Font = New System.Drawing.Font("Segoe UI", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.lblFoulHT.Location = New System.Drawing.Point(25, 140)
        Me.lblFoulHT.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblFoulHT.Name = "lblFoulHT"
        Me.lblFoulHT.Size = New System.Drawing.Size(58, 28)
        Me.lblFoulHT.TabIndex = 7
        Me.lblFoulHT.Text = "Fouls"
        '
        'lblFouls
        '
        Me.lblFouls.AutoSize = True
        Me.lblFouls.Font = New System.Drawing.Font("Segoe UI", 11.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.lblFouls.Location = New System.Drawing.Point(46, 164)
        Me.lblFouls.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblFouls.Name = "lblFouls"
        Me.lblFouls.Size = New System.Drawing.Size(18, 20)
        Me.lblFouls.TabIndex = 11
        Me.lblFouls.Text = "0"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Segoe UI", 11.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label2.Location = New System.Drawing.Point(177, 164)
        Me.Label2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(18, 20)
        Me.Label2.TabIndex = 12
        Me.Label2.Text = "0"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Segoe UI", 11.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label3.Location = New System.Drawing.Point(177, 264)
        Me.Label3.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(18, 20)
        Me.Label3.TabIndex = 13
        Me.Label3.Text = "0"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Segoe UI", 11.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label6.Location = New System.Drawing.Point(46, 264)
        Me.Label6.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(18, 20)
        Me.Label6.TabIndex = 14
        Me.Label6.Text = "0"
        '
        'lblStealsHT
        '
        Me.lblStealsHT.AutoSize = True
        Me.lblStealsHT.Font = New System.Drawing.Font("Segoe UI", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.lblStealsHT.Location = New System.Drawing.Point(153, 140)
        Me.lblStealsHT.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblStealsHT.Name = "lblStealsHT"
        Me.lblStealsHT.Size = New System.Drawing.Size(62, 28)
        Me.lblStealsHT.TabIndex = 15
        Me.lblStealsHT.Text = "Steals"
        '
        'lblBlocksHT
        '
        Me.lblBlocksHT.AutoSize = True
        Me.lblBlocksHT.Font = New System.Drawing.Font("Segoe UI", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.lblBlocksHT.Location = New System.Drawing.Point(153, 239)
        Me.lblBlocksHT.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblBlocksHT.Name = "lblBlocksHT"
        Me.lblBlocksHT.Size = New System.Drawing.Size(67, 28)
        Me.lblBlocksHT.TabIndex = 16
        Me.lblBlocksHT.Text = "Blocks"
        '
        'lbl3pointersHT
        '
        Me.lbl3pointersHT.AutoSize = True
        Me.lbl3pointersHT.Font = New System.Drawing.Font("Segoe UI", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.lbl3pointersHT.Location = New System.Drawing.Point(13, 239)
        Me.lbl3pointersHT.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lbl3pointersHT.Name = "lbl3pointersHT"
        Me.lbl3pointersHT.Size = New System.Drawing.Size(101, 28)
        Me.lbl3pointersHT.TabIndex = 17
        Me.lbl3pointersHT.Text = "3-Pointers"
        '
        'lbl3pointersAT
        '
        Me.lbl3pointersAT.AutoSize = True
        Me.lbl3pointersAT.Font = New System.Drawing.Font("Segoe UI", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.lbl3pointersAT.Location = New System.Drawing.Point(1093, 239)
        Me.lbl3pointersAT.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lbl3pointersAT.Name = "lbl3pointersAT"
        Me.lbl3pointersAT.Size = New System.Drawing.Size(101, 28)
        Me.lbl3pointersAT.TabIndex = 25
        Me.lbl3pointersAT.Text = "3-Pointers"
        '
        'lblBlocksAT
        '
        Me.lblBlocksAT.AutoSize = True
        Me.lblBlocksAT.Font = New System.Drawing.Font("Segoe UI", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.lblBlocksAT.Location = New System.Drawing.Point(1233, 239)
        Me.lblBlocksAT.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblBlocksAT.Name = "lblBlocksAT"
        Me.lblBlocksAT.Size = New System.Drawing.Size(67, 28)
        Me.lblBlocksAT.TabIndex = 24
        Me.lblBlocksAT.Text = "Blocks"
        '
        'lblStealsAT
        '
        Me.lblStealsAT.AutoSize = True
        Me.lblStealsAT.Font = New System.Drawing.Font("Segoe UI", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.lblStealsAT.Location = New System.Drawing.Point(1233, 140)
        Me.lblStealsAT.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblStealsAT.Name = "lblStealsAT"
        Me.lblStealsAT.Size = New System.Drawing.Size(62, 28)
        Me.lblStealsAT.TabIndex = 23
        Me.lblStealsAT.Text = "Steals"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Segoe UI", 11.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label9.Location = New System.Drawing.Point(1126, 264)
        Me.Label9.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(18, 20)
        Me.Label9.TabIndex = 22
        Me.Label9.Text = "0"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Segoe UI", 11.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label10.Location = New System.Drawing.Point(1257, 264)
        Me.Label10.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(18, 20)
        Me.Label10.TabIndex = 21
        Me.Label10.Text = "0"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Segoe UI", 11.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label11.Location = New System.Drawing.Point(1257, 164)
        Me.Label11.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(18, 20)
        Me.Label11.TabIndex = 20
        Me.Label11.Text = "0"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Segoe UI", 11.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label12.Location = New System.Drawing.Point(1126, 164)
        Me.Label12.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(18, 20)
        Me.Label12.TabIndex = 19
        Me.Label12.Text = "0"
        '
        'lblFoulsAT
        '
        Me.lblFoulsAT.AutoSize = True
        Me.lblFoulsAT.Font = New System.Drawing.Font("Segoe UI", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.lblFoulsAT.Location = New System.Drawing.Point(1105, 140)
        Me.lblFoulsAT.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblFoulsAT.Name = "lblFoulsAT"
        Me.lblFoulsAT.Size = New System.Drawing.Size(58, 28)
        Me.lblFoulsAT.TabIndex = 18
        Me.lblFoulsAT.Text = "Fouls"
        '
        'lblMainClockSS
        '
        Me.lblMainClockSS.AutoSize = True
        Me.lblMainClockSS.Font = New System.Drawing.Font("Segoe UI", 86.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.lblMainClockSS.Location = New System.Drawing.Point(498, -9)
        Me.lblMainClockSS.Name = "lblMainClockSS"
        Me.lblMainClockSS.Size = New System.Drawing.Size(359, 152)
        Me.lblMainClockSS.TabIndex = 26
        Me.lblMainClockSS.Text = "00:00"
        Me.lblMainClockSS.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblMainClockMS
        '
        Me.lblMainClockMS.AutoSize = True
        Me.lblMainClockMS.Font = New System.Drawing.Font("Segoe UI", 36.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.lblMainClockMS.Location = New System.Drawing.Point(813, 93)
        Me.lblMainClockMS.Name = "lblMainClockMS"
        Me.lblMainClockMS.Size = New System.Drawing.Size(84, 65)
        Me.lblMainClockMS.TabIndex = 27
        Me.lblMainClockMS.Text = "00"
        '
        'btnEditTime
        '
        Me.btnEditTime.Location = New System.Drawing.Point(1079, 683)
        Me.btnEditTime.Name = "btnEditTime"
        Me.btnEditTime.Size = New System.Drawing.Size(123, 50)
        Me.btnEditTime.TabIndex = 28
        Me.btnEditTime.Text = "Edit Time"
        Me.btnEditTime.UseVisualStyleBackColor = True
        '
        'tmrClock
        '
        Me.tmrClock.Interval = 1
        '
        'lblQuarter
        '
        Me.lblQuarter.AutoSize = True
        Me.lblQuarter.Font = New System.Drawing.Font("Segoe UI", 36.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.lblQuarter.Location = New System.Drawing.Point(541, 201)
        Me.lblQuarter.Name = "lblQuarter"
        Me.lblQuarter.Size = New System.Drawing.Size(56, 65)
        Me.lblQuarter.TabIndex = 29
        Me.lblQuarter.Text = "1"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Segoe UI", 26.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label7.Location = New System.Drawing.Point(498, 164)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(138, 47)
        Me.Label7.TabIndex = 30
        Me.Label7.Text = "Quarter"
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Segoe UI", 26.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label8.Location = New System.Drawing.Point(728, 172)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(147, 47)
        Me.Label8.TabIndex = 31
        Me.Label8.Text = "Stadium"
        Me.Label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblStadium
        '
        Me.lblStadium.AutoSize = True
        Me.lblStadium.Font = New System.Drawing.Font("Segoe UI", 36.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.lblStadium.Location = New System.Drawing.Point(686, 210)
        Me.lblStadium.Name = "lblStadium"
        Me.lblStadium.Size = New System.Drawing.Size(245, 65)
        Me.lblStadium.TabIndex = 32
        Me.lblStadium.Text = "STADIUM"
        Me.lblStadium.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btnStadium
        '
        Me.btnStadium.Location = New System.Drawing.Point(950, 682)
        Me.btnStadium.Name = "btnStadium"
        Me.btnStadium.Size = New System.Drawing.Size(123, 50)
        Me.btnStadium.TabIndex = 33
        Me.btnStadium.Text = "Edit Stadium"
        Me.btnStadium.UseVisualStyleBackColor = True
        '
        'btnStart
        '
        Me.btnStart.Location = New System.Drawing.Point(160, 709)
        Me.btnStart.Name = "btnStart"
        Me.btnStart.Size = New System.Drawing.Size(75, 23)
        Me.btnStart.TabIndex = 34
        Me.btnStart.Text = "Start"
        Me.btnStart.UseVisualStyleBackColor = True
        '
        'btnStop
        '
        Me.btnStop.Location = New System.Drawing.Point(241, 709)
        Me.btnStop.Name = "btnStop"
        Me.btnStop.Size = New System.Drawing.Size(75, 23)
        Me.btnStop.TabIndex = 35
        Me.btnStop.Text = "Stop"
        Me.btnStop.UseVisualStyleBackColor = True
        '
        'btnReset
        '
        Me.btnReset.Location = New System.Drawing.Point(322, 709)
        Me.btnReset.Name = "btnReset"
        Me.btnReset.Size = New System.Drawing.Size(75, 23)
        Me.btnReset.TabIndex = 36
        Me.btnReset.Text = "Reset"
        Me.btnReset.UseVisualStyleBackColor = True
        '
        'btnShowController
        '
        Me.btnShowController.Font = New System.Drawing.Font("Segoe UI", 15.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.btnShowController.Location = New System.Drawing.Point(632, 681)
        Me.btnShowController.Name = "btnShowController"
        Me.btnShowController.Size = New System.Drawing.Size(180, 51)
        Me.btnShowController.TabIndex = 37
        Me.btnShowController.Text = "Show Controller"
        Me.btnShowController.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1346, 744)
        Me.Controls.Add(Me.btnShowController)
        Me.Controls.Add(Me.btnReset)
        Me.Controls.Add(Me.btnStop)
        Me.Controls.Add(Me.btnStart)
        Me.Controls.Add(Me.btnStadium)
        Me.Controls.Add(Me.lblStadium)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.lblQuarter)
        Me.Controls.Add(Me.btnEditTime)
        Me.Controls.Add(Me.lblMainClockMS)
        Me.Controls.Add(Me.lblMainClockSS)
        Me.Controls.Add(Me.lbl3pointersAT)
        Me.Controls.Add(Me.lblBlocksAT)
        Me.Controls.Add(Me.lblStealsAT)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.lblFoulsAT)
        Me.Controls.Add(Me.lbl3pointersHT)
        Me.Controls.Add(Me.lblBlocksHT)
        Me.Controls.Add(Me.lblStealsHT)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.lblFouls)
        Me.Controls.Add(Me.lblFoulHT)
        Me.Controls.Add(Me.btnChangeTMs)
        Me.Controls.Add(Me.lblAwayTM)
        Me.Controls.Add(Me.lblHomeTM)
        Me.Controls.Add(Me.lblHTpnts)
        Me.Controls.Add(Me.lblATpnts)
        Me.Margin = New System.Windows.Forms.Padding(2)
        Me.Name = "Form1"
        Me.Text = "Basketball Scoreboard - Yash, Hang, Fatehpal, Madit"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblHomeTM As Label
    Friend WithEvents lblAwayTM As Label
    Friend WithEvents btnChangeTMs As Button
    Friend WithEvents lblHTpnts As Label
    Friend WithEvents lblATpnts As Label
    Friend WithEvents lblFoulHT As Label
    Friend WithEvents lblFouls As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents lblStealsHT As Label
    Friend WithEvents lblBlocksHT As Label
    Friend WithEvents lbl3pointersHT As Label
    Friend WithEvents lbl3pointersAT As Label
    Friend WithEvents lblBlocksAT As Label
    Friend WithEvents lblStealsAT As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents lblFoulsAT As Label
    Friend WithEvents lblMainClockSS As Label
    Friend WithEvents lblMainClockMS As Label
    Friend WithEvents btnEditTime As Button
    Friend WithEvents tmrClock As Timer
    Friend WithEvents lblQuarter As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents lblStadium As Label
    Friend WithEvents btnStadium As Button
    Friend WithEvents btnStart As Button
    Friend WithEvents btnStop As Button
    Friend WithEvents btnReset As Button
    Friend WithEvents btnShowController As Button
End Class
