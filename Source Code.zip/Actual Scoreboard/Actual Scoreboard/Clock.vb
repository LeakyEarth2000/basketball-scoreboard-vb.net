﻿Public Class Clock

End Class