﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Controller
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.btnT1Sp1 = New System.Windows.Forms.Button()
        Me.lblT1 = New System.Windows.Forms.Label()
        Me.btnQuarterplus1 = New System.Windows.Forms.Button()
        Me.btnT1Sn1 = New System.Windows.Forms.Button()
        Me.btnT1Sn2 = New System.Windows.Forms.Button()
        Me.btnT1Sp2 = New System.Windows.Forms.Button()
        Me.btnT1Sp3 = New System.Windows.Forms.Button()
        Me.btnT1Sn3 = New System.Windows.Forms.Button()
        Me.btnQuarterminus1 = New System.Windows.Forms.Button()
        Me.lblBlocks = New System.Windows.Forms.Label()
        Me.lblFoul = New System.Windows.Forms.Label()
        Me.btnT2Sp1 = New System.Windows.Forms.Button()
        Me.btnT2Sn1 = New System.Windows.Forms.Button()
        Me.btnT2Sp2 = New System.Windows.Forms.Button()
        Me.btnT2Sn2 = New System.Windows.Forms.Button()
        Me.btnT2Sp3 = New System.Windows.Forms.Button()
        Me.btnT2Sn3 = New System.Windows.Forms.Button()
        Me.lblT2 = New System.Windows.Forms.Label()
        Me.btnPauseShotClock = New System.Windows.Forms.Button()
        Me.btnShotClockReset = New System.Windows.Forms.Button()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.lblSteals = New System.Windows.Forms.Label()
        Me.lblAssist = New System.Windows.Forms.Label()
        Me.lblRebounds = New System.Windows.Forms.Label()
        Me.lblFouls2 = New System.Windows.Forms.Label()
        Me.lblBlocks2 = New System.Windows.Forms.Label()
        Me.lblAssist2 = New System.Windows.Forms.Label()
        Me.lblSteals2 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.btnT1Reboundsp = New System.Windows.Forms.Button()
        Me.btnT1Stealsp = New System.Windows.Forms.Button()
        Me.btnT1Assistsp = New System.Windows.Forms.Button()
        Me.btnT1Blocksp = New System.Windows.Forms.Button()
        Me.btnT1Foulsp = New System.Windows.Forms.Button()
        Me.btnT2Reboundsp = New System.Windows.Forms.Button()
        Me.btnT2Stealsp = New System.Windows.Forms.Button()
        Me.btnT2Assistsp = New System.Windows.Forms.Button()
        Me.btnT2Blocksp = New System.Windows.Forms.Button()
        Me.btnT2Foulsp = New System.Windows.Forms.Button()
        Me.btnT2Stealsn = New System.Windows.Forms.Button()
        Me.btnT1Reboundsn = New System.Windows.Forms.Button()
        Me.btnT1Stealsn = New System.Windows.Forms.Button()
        Me.btnT1Assistsn = New System.Windows.Forms.Button()
        Me.btnT1Blocksn = New System.Windows.Forms.Button()
        Me.btnT1Foulsn = New System.Windows.Forms.Button()
        Me.btnT2Assistsn = New System.Windows.Forms.Button()
        Me.btnT2Blocksn = New System.Windows.Forms.Button()
        Me.btnT2Foulsn = New System.Windows.Forms.Button()
        Me.btnT2Reboundsn = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'btnT1Sp1
        '
        Me.btnT1Sp1.Location = New System.Drawing.Point(29, 351)
        Me.btnT1Sp1.Name = "btnT1Sp1"
        Me.btnT1Sp1.Size = New System.Drawing.Size(45, 23)
        Me.btnT1Sp1.TabIndex = 0
        Me.btnT1Sp1.Text = "+1"
        Me.btnT1Sp1.UseVisualStyleBackColor = True
        '
        'lblT1
        '
        Me.lblT1.AutoSize = True
        Me.lblT1.Font = New System.Drawing.Font("Stencil", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.lblT1.Location = New System.Drawing.Point(46, 19)
        Me.lblT1.Name = "lblT1"
        Me.lblT1.Size = New System.Drawing.Size(107, 32)
        Me.lblT1.TabIndex = 1
        Me.lblT1.Text = "Team 1"
        '
        'btnQuarterplus1
        '
        Me.btnQuarterplus1.Location = New System.Drawing.Point(354, 312)
        Me.btnQuarterplus1.Name = "btnQuarterplus1"
        Me.btnQuarterplus1.Size = New System.Drawing.Size(34, 23)
        Me.btnQuarterplus1.TabIndex = 4
        Me.btnQuarterplus1.Text = "+1"
        Me.btnQuarterplus1.UseVisualStyleBackColor = True
        '
        'btnT1Sn1
        '
        Me.btnT1Sn1.Location = New System.Drawing.Point(29, 380)
        Me.btnT1Sn1.Name = "btnT1Sn1"
        Me.btnT1Sn1.Size = New System.Drawing.Size(45, 23)
        Me.btnT1Sn1.TabIndex = 5
        Me.btnT1Sn1.Text = "-1"
        Me.btnT1Sn1.UseVisualStyleBackColor = True
        '
        'btnT1Sn2
        '
        Me.btnT1Sn2.Location = New System.Drawing.Point(89, 380)
        Me.btnT1Sn2.Name = "btnT1Sn2"
        Me.btnT1Sn2.Size = New System.Drawing.Size(45, 23)
        Me.btnT1Sn2.TabIndex = 6
        Me.btnT1Sn2.Text = "-2"
        Me.btnT1Sn2.UseVisualStyleBackColor = True
        '
        'btnT1Sp2
        '
        Me.btnT1Sp2.Location = New System.Drawing.Point(89, 351)
        Me.btnT1Sp2.Name = "btnT1Sp2"
        Me.btnT1Sp2.Size = New System.Drawing.Size(45, 23)
        Me.btnT1Sp2.TabIndex = 7
        Me.btnT1Sp2.Text = "+2"
        Me.btnT1Sp2.UseVisualStyleBackColor = True
        '
        'btnT1Sp3
        '
        Me.btnT1Sp3.Location = New System.Drawing.Point(150, 351)
        Me.btnT1Sp3.Name = "btnT1Sp3"
        Me.btnT1Sp3.Size = New System.Drawing.Size(45, 23)
        Me.btnT1Sp3.TabIndex = 10
        Me.btnT1Sp3.Text = "+3"
        Me.btnT1Sp3.UseVisualStyleBackColor = True
        '
        'btnT1Sn3
        '
        Me.btnT1Sn3.Location = New System.Drawing.Point(150, 380)
        Me.btnT1Sn3.Name = "btnT1Sn3"
        Me.btnT1Sn3.Size = New System.Drawing.Size(45, 23)
        Me.btnT1Sn3.TabIndex = 11
        Me.btnT1Sn3.Text = "-3"
        Me.btnT1Sn3.UseVisualStyleBackColor = True
        '
        'btnQuarterminus1
        '
        Me.btnQuarterminus1.Location = New System.Drawing.Point(408, 312)
        Me.btnQuarterminus1.Name = "btnQuarterminus1"
        Me.btnQuarterminus1.Size = New System.Drawing.Size(34, 23)
        Me.btnQuarterminus1.TabIndex = 13
        Me.btnQuarterminus1.Text = "-1" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        Me.btnQuarterminus1.UseVisualStyleBackColor = True
        '
        'lblBlocks
        '
        Me.lblBlocks.AutoSize = True
        Me.lblBlocks.Font = New System.Drawing.Font("Stencil", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.lblBlocks.Location = New System.Drawing.Point(54, 488)
        Me.lblBlocks.Name = "lblBlocks"
        Me.lblBlocks.Size = New System.Drawing.Size(69, 19)
        Me.lblBlocks.TabIndex = 14
        Me.lblBlocks.Text = "Blocks"
        '
        'lblFoul
        '
        Me.lblFoul.AutoSize = True
        Me.lblFoul.Font = New System.Drawing.Font("Stencil", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.lblFoul.Location = New System.Drawing.Point(62, 434)
        Me.lblFoul.Name = "lblFoul"
        Me.lblFoul.Size = New System.Drawing.Size(57, 19)
        Me.lblFoul.TabIndex = 15
        Me.lblFoul.Text = "Fouls"
        '
        'btnT2Sp1
        '
        Me.btnT2Sp1.Location = New System.Drawing.Point(631, 351)
        Me.btnT2Sp1.Name = "btnT2Sp1"
        Me.btnT2Sp1.Size = New System.Drawing.Size(45, 23)
        Me.btnT2Sp1.TabIndex = 16
        Me.btnT2Sp1.Text = "+1"
        Me.btnT2Sp1.UseVisualStyleBackColor = True
        '
        'btnT2Sn1
        '
        Me.btnT2Sn1.Location = New System.Drawing.Point(631, 380)
        Me.btnT2Sn1.Name = "btnT2Sn1"
        Me.btnT2Sn1.Size = New System.Drawing.Size(45, 23)
        Me.btnT2Sn1.TabIndex = 17
        Me.btnT2Sn1.Text = "-1"
        Me.btnT2Sn1.UseVisualStyleBackColor = True
        '
        'btnT2Sp2
        '
        Me.btnT2Sp2.Location = New System.Drawing.Point(691, 351)
        Me.btnT2Sp2.Name = "btnT2Sp2"
        Me.btnT2Sp2.Size = New System.Drawing.Size(45, 23)
        Me.btnT2Sp2.TabIndex = 18
        Me.btnT2Sp2.Text = "+2"
        Me.btnT2Sp2.UseVisualStyleBackColor = True
        '
        'btnT2Sn2
        '
        Me.btnT2Sn2.Location = New System.Drawing.Point(691, 380)
        Me.btnT2Sn2.Name = "btnT2Sn2"
        Me.btnT2Sn2.Size = New System.Drawing.Size(45, 23)
        Me.btnT2Sn2.TabIndex = 19
        Me.btnT2Sn2.Text = "-2"
        Me.btnT2Sn2.UseVisualStyleBackColor = True
        '
        'btnT2Sp3
        '
        Me.btnT2Sp3.Location = New System.Drawing.Point(752, 351)
        Me.btnT2Sp3.Name = "btnT2Sp3"
        Me.btnT2Sp3.Size = New System.Drawing.Size(45, 23)
        Me.btnT2Sp3.TabIndex = 20
        Me.btnT2Sp3.Text = "+3"
        Me.btnT2Sp3.UseVisualStyleBackColor = True
        '
        'btnT2Sn3
        '
        Me.btnT2Sn3.Location = New System.Drawing.Point(752, 380)
        Me.btnT2Sn3.Name = "btnT2Sn3"
        Me.btnT2Sn3.Size = New System.Drawing.Size(45, 23)
        Me.btnT2Sn3.TabIndex = 22
        Me.btnT2Sn3.Text = "-3"
        Me.btnT2Sn3.UseVisualStyleBackColor = True
        '
        'lblT2
        '
        Me.lblT2.Font = New System.Drawing.Font("Stencil", 20.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.lblT2.Location = New System.Drawing.Point(645, 19)
        Me.lblT2.Name = "lblT2"
        Me.lblT2.Size = New System.Drawing.Size(122, 32)
        Me.lblT2.TabIndex = 25
        Me.lblT2.Text = "Team 2"
        '
        'btnPauseShotClock
        '
        Me.btnPauseShotClock.Location = New System.Drawing.Point(273, 242)
        Me.btnPauseShotClock.Name = "btnPauseShotClock"
        Me.btnPauseShotClock.Size = New System.Drawing.Size(75, 23)
        Me.btnPauseShotClock.TabIndex = 30
        Me.btnPauseShotClock.Text = "Pause"
        Me.btnPauseShotClock.UseVisualStyleBackColor = True
        '
        'btnShotClockReset
        '
        Me.btnShotClockReset.Location = New System.Drawing.Point(427, 242)
        Me.btnShotClockReset.Name = "btnShotClockReset"
        Me.btnShotClockReset.Size = New System.Drawing.Size(75, 23)
        Me.btnShotClockReset.TabIndex = 31
        Me.btnShotClockReset.Text = "Reset"
        Me.btnShotClockReset.UseVisualStyleBackColor = True
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Stencil", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label3.Location = New System.Drawing.Point(46, 316)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(116, 19)
        Me.Label3.TabIndex = 33
        Me.Label3.Text = "Team 1 Score"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Stencil", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label4.Location = New System.Drawing.Point(660, 316)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(116, 19)
        Me.Label4.TabIndex = 34
        Me.Label4.Text = "Team 2 Score"
        '
        'lblSteals
        '
        Me.lblSteals.AutoSize = True
        Me.lblSteals.Font = New System.Drawing.Font("Stencil", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.lblSteals.Location = New System.Drawing.Point(54, 593)
        Me.lblSteals.Name = "lblSteals"
        Me.lblSteals.Size = New System.Drawing.Size(65, 19)
        Me.lblSteals.TabIndex = 35
        Me.lblSteals.Text = "Steals"
        '
        'lblAssist
        '
        Me.lblAssist.AutoSize = True
        Me.lblAssist.Font = New System.Drawing.Font("Stencil", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.lblAssist.Location = New System.Drawing.Point(62, 539)
        Me.lblAssist.Name = "lblAssist"
        Me.lblAssist.Size = New System.Drawing.Size(62, 19)
        Me.lblAssist.TabIndex = 36
        Me.lblAssist.Text = "Assist"
        '
        'lblRebounds
        '
        Me.lblRebounds.AutoSize = True
        Me.lblRebounds.Font = New System.Drawing.Font("Stencil", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.lblRebounds.Location = New System.Drawing.Point(29, 645)
        Me.lblRebounds.Name = "lblRebounds"
        Me.lblRebounds.Size = New System.Drawing.Size(91, 19)
        Me.lblRebounds.TabIndex = 37
        Me.lblRebounds.Text = "Rebounds"
        '
        'lblFouls2
        '
        Me.lblFouls2.AutoSize = True
        Me.lblFouls2.Font = New System.Drawing.Font("Stencil", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.lblFouls2.Location = New System.Drawing.Point(714, 431)
        Me.lblFouls2.Name = "lblFouls2"
        Me.lblFouls2.Size = New System.Drawing.Size(57, 19)
        Me.lblFouls2.TabIndex = 38
        Me.lblFouls2.Text = "Fouls"
        '
        'lblBlocks2
        '
        Me.lblBlocks2.AutoSize = True
        Me.lblBlocks2.Font = New System.Drawing.Font("Stencil", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.lblBlocks2.Location = New System.Drawing.Point(707, 487)
        Me.lblBlocks2.Name = "lblBlocks2"
        Me.lblBlocks2.Size = New System.Drawing.Size(69, 19)
        Me.lblBlocks2.TabIndex = 39
        Me.lblBlocks2.Text = "Blocks"
        '
        'lblAssist2
        '
        Me.lblAssist2.AutoSize = True
        Me.lblAssist2.Font = New System.Drawing.Font("Stencil", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.lblAssist2.Location = New System.Drawing.Point(714, 539)
        Me.lblAssist2.Name = "lblAssist2"
        Me.lblAssist2.Size = New System.Drawing.Size(62, 19)
        Me.lblAssist2.TabIndex = 40
        Me.lblAssist2.Text = "Assist"
        '
        'lblSteals2
        '
        Me.lblSteals2.AutoSize = True
        Me.lblSteals2.Font = New System.Drawing.Font("Stencil", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.lblSteals2.Location = New System.Drawing.Point(711, 594)
        Me.lblSteals2.Name = "lblSteals2"
        Me.lblSteals2.Size = New System.Drawing.Size(65, 19)
        Me.lblSteals2.TabIndex = 41
        Me.lblSteals2.Text = "Steals"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Stencil", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label9.Location = New System.Drawing.Point(685, 645)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(91, 19)
        Me.Label9.TabIndex = 42
        Me.Label9.Text = "Rebounds"
        '
        'btnT1Reboundsp
        '
        Me.btnT1Reboundsp.Location = New System.Drawing.Point(182, 644)
        Me.btnT1Reboundsp.Name = "btnT1Reboundsp"
        Me.btnT1Reboundsp.Size = New System.Drawing.Size(75, 23)
        Me.btnT1Reboundsp.TabIndex = 53
        Me.btnT1Reboundsp.Text = "+1"
        Me.btnT1Reboundsp.UseVisualStyleBackColor = True
        '
        'btnT1Stealsp
        '
        Me.btnT1Stealsp.Location = New System.Drawing.Point(182, 593)
        Me.btnT1Stealsp.Name = "btnT1Stealsp"
        Me.btnT1Stealsp.Size = New System.Drawing.Size(75, 23)
        Me.btnT1Stealsp.TabIndex = 54
        Me.btnT1Stealsp.Text = "+1"
        Me.btnT1Stealsp.UseVisualStyleBackColor = True
        '
        'btnT1Assistsp
        '
        Me.btnT1Assistsp.Location = New System.Drawing.Point(182, 539)
        Me.btnT1Assistsp.Name = "btnT1Assistsp"
        Me.btnT1Assistsp.Size = New System.Drawing.Size(75, 23)
        Me.btnT1Assistsp.TabIndex = 55
        Me.btnT1Assistsp.Text = "+1"
        Me.btnT1Assistsp.UseVisualStyleBackColor = True
        '
        'btnT1Blocksp
        '
        Me.btnT1Blocksp.Location = New System.Drawing.Point(182, 486)
        Me.btnT1Blocksp.Name = "btnT1Blocksp"
        Me.btnT1Blocksp.Size = New System.Drawing.Size(75, 23)
        Me.btnT1Blocksp.TabIndex = 56
        Me.btnT1Blocksp.Text = "+1"
        Me.btnT1Blocksp.UseVisualStyleBackColor = True
        '
        'btnT1Foulsp
        '
        Me.btnT1Foulsp.Location = New System.Drawing.Point(182, 433)
        Me.btnT1Foulsp.Name = "btnT1Foulsp"
        Me.btnT1Foulsp.Size = New System.Drawing.Size(75, 23)
        Me.btnT1Foulsp.TabIndex = 57
        Me.btnT1Foulsp.Text = "+1"
        Me.btnT1Foulsp.UseVisualStyleBackColor = True
        '
        'btnT2Reboundsp
        '
        Me.btnT2Reboundsp.Location = New System.Drawing.Point(524, 644)
        Me.btnT2Reboundsp.Name = "btnT2Reboundsp"
        Me.btnT2Reboundsp.Size = New System.Drawing.Size(75, 23)
        Me.btnT2Reboundsp.TabIndex = 58
        Me.btnT2Reboundsp.Text = "+1"
        Me.btnT2Reboundsp.UseVisualStyleBackColor = True
        '
        'btnT2Stealsp
        '
        Me.btnT2Stealsp.Location = New System.Drawing.Point(524, 592)
        Me.btnT2Stealsp.Name = "btnT2Stealsp"
        Me.btnT2Stealsp.Size = New System.Drawing.Size(75, 23)
        Me.btnT2Stealsp.TabIndex = 59
        Me.btnT2Stealsp.Text = "+1"
        Me.btnT2Stealsp.UseVisualStyleBackColor = True
        '
        'btnT2Assistsp
        '
        Me.btnT2Assistsp.Location = New System.Drawing.Point(524, 539)
        Me.btnT2Assistsp.Name = "btnT2Assistsp"
        Me.btnT2Assistsp.Size = New System.Drawing.Size(75, 23)
        Me.btnT2Assistsp.TabIndex = 60
        Me.btnT2Assistsp.Text = "+1"
        Me.btnT2Assistsp.UseVisualStyleBackColor = True
        '
        'btnT2Blocksp
        '
        Me.btnT2Blocksp.Location = New System.Drawing.Point(524, 486)
        Me.btnT2Blocksp.Name = "btnT2Blocksp"
        Me.btnT2Blocksp.Size = New System.Drawing.Size(75, 23)
        Me.btnT2Blocksp.TabIndex = 61
        Me.btnT2Blocksp.Text = "+1"
        Me.btnT2Blocksp.UseVisualStyleBackColor = True
        '
        'btnT2Foulsp
        '
        Me.btnT2Foulsp.Location = New System.Drawing.Point(524, 430)
        Me.btnT2Foulsp.Name = "btnT2Foulsp"
        Me.btnT2Foulsp.Size = New System.Drawing.Size(75, 23)
        Me.btnT2Foulsp.TabIndex = 62
        Me.btnT2Foulsp.Text = "+1"
        Me.btnT2Foulsp.UseVisualStyleBackColor = True
        '
        'btnT2Stealsn
        '
        Me.btnT2Stealsn.Location = New System.Drawing.Point(443, 592)
        Me.btnT2Stealsn.Name = "btnT2Stealsn"
        Me.btnT2Stealsn.Size = New System.Drawing.Size(75, 23)
        Me.btnT2Stealsn.TabIndex = 63
        Me.btnT2Stealsn.Text = "-1"
        Me.btnT2Stealsn.UseVisualStyleBackColor = True
        '
        'btnT1Reboundsn
        '
        Me.btnT1Reboundsn.Location = New System.Drawing.Point(263, 644)
        Me.btnT1Reboundsn.Name = "btnT1Reboundsn"
        Me.btnT1Reboundsn.Size = New System.Drawing.Size(75, 23)
        Me.btnT1Reboundsn.TabIndex = 64
        Me.btnT1Reboundsn.Text = "-1"
        Me.btnT1Reboundsn.UseVisualStyleBackColor = True
        '
        'btnT1Stealsn
        '
        Me.btnT1Stealsn.Location = New System.Drawing.Point(263, 592)
        Me.btnT1Stealsn.Name = "btnT1Stealsn"
        Me.btnT1Stealsn.Size = New System.Drawing.Size(75, 23)
        Me.btnT1Stealsn.TabIndex = 65
        Me.btnT1Stealsn.Text = "-1"
        Me.btnT1Stealsn.UseVisualStyleBackColor = True
        '
        'btnT1Assistsn
        '
        Me.btnT1Assistsn.Location = New System.Drawing.Point(263, 539)
        Me.btnT1Assistsn.Name = "btnT1Assistsn"
        Me.btnT1Assistsn.Size = New System.Drawing.Size(75, 23)
        Me.btnT1Assistsn.TabIndex = 66
        Me.btnT1Assistsn.Text = "-1"
        Me.btnT1Assistsn.UseVisualStyleBackColor = True
        '
        'btnT1Blocksn
        '
        Me.btnT1Blocksn.Location = New System.Drawing.Point(263, 486)
        Me.btnT1Blocksn.Name = "btnT1Blocksn"
        Me.btnT1Blocksn.Size = New System.Drawing.Size(75, 23)
        Me.btnT1Blocksn.TabIndex = 67
        Me.btnT1Blocksn.Text = "-1"
        Me.btnT1Blocksn.UseVisualStyleBackColor = True
        '
        'btnT1Foulsn
        '
        Me.btnT1Foulsn.Location = New System.Drawing.Point(263, 433)
        Me.btnT1Foulsn.Name = "btnT1Foulsn"
        Me.btnT1Foulsn.Size = New System.Drawing.Size(75, 23)
        Me.btnT1Foulsn.TabIndex = 68
        Me.btnT1Foulsn.Text = "-1"
        Me.btnT1Foulsn.UseVisualStyleBackColor = True
        '
        'btnT2Assistsn
        '
        Me.btnT2Assistsn.Location = New System.Drawing.Point(443, 539)
        Me.btnT2Assistsn.Name = "btnT2Assistsn"
        Me.btnT2Assistsn.Size = New System.Drawing.Size(75, 23)
        Me.btnT2Assistsn.TabIndex = 70
        Me.btnT2Assistsn.Text = "-1"
        Me.btnT2Assistsn.UseVisualStyleBackColor = True
        '
        'btnT2Blocksn
        '
        Me.btnT2Blocksn.Location = New System.Drawing.Point(443, 487)
        Me.btnT2Blocksn.Name = "btnT2Blocksn"
        Me.btnT2Blocksn.Size = New System.Drawing.Size(75, 23)
        Me.btnT2Blocksn.TabIndex = 71
        Me.btnT2Blocksn.Text = "-1"
        Me.btnT2Blocksn.UseVisualStyleBackColor = True
        '
        'btnT2Foulsn
        '
        Me.btnT2Foulsn.Location = New System.Drawing.Point(443, 430)
        Me.btnT2Foulsn.Name = "btnT2Foulsn"
        Me.btnT2Foulsn.Size = New System.Drawing.Size(75, 23)
        Me.btnT2Foulsn.TabIndex = 72
        Me.btnT2Foulsn.Text = "-1"
        Me.btnT2Foulsn.UseVisualStyleBackColor = True
        '
        'btnT2Reboundsn
        '
        Me.btnT2Reboundsn.Location = New System.Drawing.Point(443, 645)
        Me.btnT2Reboundsn.Name = "btnT2Reboundsn"
        Me.btnT2Reboundsn.Size = New System.Drawing.Size(75, 23)
        Me.btnT2Reboundsn.TabIndex = 74
        Me.btnT2Reboundsn.Text = "-1"
        Me.btnT2Reboundsn.UseVisualStyleBackColor = True
        '
        'Controller
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1336, 697)
        Me.Controls.Add(Me.btnT2Reboundsn)
        Me.Controls.Add(Me.btnT2Foulsn)
        Me.Controls.Add(Me.btnT2Blocksn)
        Me.Controls.Add(Me.btnT2Assistsn)
        Me.Controls.Add(Me.btnT1Foulsn)
        Me.Controls.Add(Me.btnT1Blocksn)
        Me.Controls.Add(Me.btnT1Assistsn)
        Me.Controls.Add(Me.btnT1Stealsn)
        Me.Controls.Add(Me.btnT1Reboundsn)
        Me.Controls.Add(Me.btnT2Stealsn)
        Me.Controls.Add(Me.btnT2Foulsp)
        Me.Controls.Add(Me.btnT2Blocksp)
        Me.Controls.Add(Me.btnT2Assistsp)
        Me.Controls.Add(Me.btnT2Stealsp)
        Me.Controls.Add(Me.btnT2Reboundsp)
        Me.Controls.Add(Me.btnT1Foulsp)
        Me.Controls.Add(Me.btnT1Blocksp)
        Me.Controls.Add(Me.btnT1Assistsp)
        Me.Controls.Add(Me.btnT1Stealsp)
        Me.Controls.Add(Me.btnT1Reboundsp)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.lblSteals2)
        Me.Controls.Add(Me.lblAssist2)
        Me.Controls.Add(Me.lblBlocks2)
        Me.Controls.Add(Me.lblFouls2)
        Me.Controls.Add(Me.lblRebounds)
        Me.Controls.Add(Me.lblAssist)
        Me.Controls.Add(Me.lblSteals)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.btnShotClockReset)
        Me.Controls.Add(Me.btnPauseShotClock)
        Me.Controls.Add(Me.lblT2)
        Me.Controls.Add(Me.btnT2Sn3)
        Me.Controls.Add(Me.btnT2Sp3)
        Me.Controls.Add(Me.btnT2Sn2)
        Me.Controls.Add(Me.btnT2Sp2)
        Me.Controls.Add(Me.btnT2Sn1)
        Me.Controls.Add(Me.btnT2Sp1)
        Me.Controls.Add(Me.lblFoul)
        Me.Controls.Add(Me.lblBlocks)
        Me.Controls.Add(Me.btnQuarterminus1)
        Me.Controls.Add(Me.btnT1Sn3)
        Me.Controls.Add(Me.btnT1Sp3)
        Me.Controls.Add(Me.btnT1Sp2)
        Me.Controls.Add(Me.btnT1Sn2)
        Me.Controls.Add(Me.btnT1Sn1)
        Me.Controls.Add(Me.btnQuarterplus1)
        Me.Controls.Add(Me.lblT1)
        Me.Controls.Add(Me.btnT1Sp1)
        Me.Name = "Controller"
        Me.Text = "   "
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnT1Sp1 As Button
    Friend WithEvents lblT1 As Label
    Friend WithEvents btnQuarterplus1 As Button
    Friend WithEvents btnT1Sn1 As Button
    Friend WithEvents btnT1Sn2 As Button
    Friend WithEvents btnT1Sp2 As Button
    Friend WithEvents btnT1Sp3 As Button
    Friend WithEvents btnT1Sn3 As Button
    Friend WithEvents btnQuarterminus1 As Button
    Friend WithEvents lblBlocks As Label
    Friend WithEvents lblFoul As Label
    Friend WithEvents btnT2Sp1 As Button
    Friend WithEvents btnT2Sn1 As Button
    Friend WithEvents btnT2Sp2 As Button
    Friend WithEvents btnT2Sn2 As Button
    Friend WithEvents btnT2Sp3 As Button
    Friend WithEvents btnT2Sn3 As Button
    Friend WithEvents lblT2 As Label
    Friend WithEvents btnPauseShotClock As Button
    Friend WithEvents btnShotClockReset As Button
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents lblSteals As Label
    Friend WithEvents lblAssist As Label
    Friend WithEvents lblRebounds As Label
    Friend WithEvents lblFouls2 As Label
    Friend WithEvents lblBlocks2 As Label
    Friend WithEvents lblAssist2 As Label
    Friend WithEvents lblSteals2 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents btnT1Reboundsp As Button
    Friend WithEvents btnT1Stealsp As Button
    Friend WithEvents btnT1Assistsp As Button
    Friend WithEvents btnT1Blocksp As Button
    Friend WithEvents btnT1Foulsp As Button
    Friend WithEvents btnT2Reboundsp As Button
    Friend WithEvents btnT2Stealsp As Button
    Friend WithEvents btnT2Assistsp As Button
    Friend WithEvents btnT2Blocksp As Button
    Friend WithEvents btnT2Foulsp As Button
    Friend WithEvents btnT2Stealsn As Button
    Friend WithEvents btnT1Reboundsn As Button
    Friend WithEvents btnT1Stealsn As Button
    Friend WithEvents btnT1Assistsn As Button
    Friend WithEvents btnT1Blocksn As Button
    Friend WithEvents btnT1Foulsn As Button
    Friend WithEvents btnT2Assistsn As Button
    Friend WithEvents btnT2Blocksn As Button
    Friend WithEvents btnT2Foulsn As Button
    Friend WithEvents btnT2Reboundsn As Button
End Class
